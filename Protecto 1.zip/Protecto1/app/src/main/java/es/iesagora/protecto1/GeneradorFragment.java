package es.iesagora.protecto1;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import es.iesagora.protecto1.databinding.FragmentGeneradorBinding;
import es.iesagora.protecto1.databinding.FragmentPokedexBinding;

public class GeneradorFragment extends Fragment {

    private FragmentGeneradorBinding binding;
    private PokemonRepository repository;
    private PokemonAdapter adapter;


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentGeneradorBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Obtenemos la lista desde el Repository
        repository = new PokemonRepository();
        List<Pokemon> listaAnimales = repository.getAnimales();
        binding.Generador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int respuesta = (int) (Math.random() * listaAnimales.toArray().length) + 0;
                binding.Imagen.setImageResource(listaAnimales.get(respuesta).getImagen());
                List<Pokemon> listaEquipo = repository.getEquipo();
                if (listaEquipo == null || listaEquipo.isEmpty()) {
                    repository.aniadirpokemon(listaAnimales.get(respuesta));
                } else {
                    boolean existe = false;
                    for (Pokemon p : listaEquipo) {
                        if (p.getNombre().equals(listaAnimales.get(respuesta).getNombre())) {
                            existe = true;
                            break;
                        }
                    }

                    if (!existe) {
                        repository.aniadirpokemon(listaAnimales.get(respuesta));
                    }
                }
            }
        });


    }
}