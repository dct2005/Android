package es.iesagora.protecto1;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.protecto1.databinding.ViewholderPokemonBinding;

public class PokemonAdapter extends RecyclerView.Adapter<PokemonAdapter.PokemonviewHolder> {
    private List<Pokemon> pokemons;            // Lista de animales a mostrar
    private final LayoutInflater inflater;    // Crea (infla) las vistas desde XML

    // Constructor: recibe el contexto y la lista de animales
    public PokemonAdapter(Context context, List<Pokemon> animales) {
        this.pokemons = animales;
        this.inflater = LayoutInflater.from(context);
    }


    @NonNull
    @Override
    public PokemonviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.viewholder_pokemon, parent, false);
        return new PokemonviewHolder(view);
    }


    // Indica cuántos elementos hay en la lista
    @Override
    public int getItemCount() {
        return pokemons != null ? pokemons.size() : 0;
    }

    // Permite actualizar la lista completa desde fuera del adaptador
    public void establecerLista(List<Pokemon> animales) {
        this.pokemons = animales;
        notifyDataSetChanged(); // Notifica al RecyclerView que los datos han cambiado
    }

    // Clase interna ViewHolder que representa un solo elemento con ViewBinding
    public static class PokemonviewHolder extends RecyclerView.ViewHolder {

        // Objeto de enlace al layout viewholder_animal.xml
        ViewholderPokemonBinding binding;

        // El constructor recibe la vista del layout inflado
        public PokemonviewHolder(@NonNull View itemView) {
            super(itemView);
            // Asociamos el objeto binding con la vista
            binding = ViewholderPokemonBinding.bind(itemView);
        }
    }

    public void onBindViewHolder(@NonNull PokemonviewHolder holder, int position) {
        Pokemon animal = pokemons.get(position);

        holder.binding.tvNombre.setText(animal.getNombre());
        holder.binding.ivpokemon.setImageResource(animal.getImagen());

        // Detectar el click sobre la tarjeta
        holder.itemView.setOnClickListener(v -> {
            // 1. Crear un Bundle con el animal seleccionado
            Bundle bundle = new Bundle();
            bundle.putSerializable("animal", animal);

            // 2. Navegar al fragmento de detalle usando NavController
            NavController navController = Navigation.findNavController(v);
            navController.navigate(R.id.action_pokedexFragment_to_detallePokemonFragment, bundle);
        });
    }
}

