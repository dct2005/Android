package es.iesagora.protecto1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayoutMediator;

import java.util.List;

import es.iesagora.protecto1.databinding.FragmentPokedexBinding;


public class PokedexFragment extends Fragment {
    private FragmentPokedexBinding binding;
    private PokemonRepository repository;
    private PokemonAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentPokedexBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 1️⃣ Configuramos el adaptador que define qué fragment se muestra en cada pestaña
        establecerAdaptadorViewPager();

        // 2️⃣ Vinculamos el TabLayout con el ViewPager2 para sincronizar ambos componentes
        vincularTabLayoutConViewPager();
        // Obtenemos la lista desde el Repository
        }
    private void establecerAdaptadorViewPager() {
        binding.viewPager.setAdapter(new FragmentStateAdapter(this) {
            @NonNull
            @Override
            public Fragment createFragment(int position) {
                // Devuelve el fragment correspondiente a cada pestaña
                switch (position) {
                    default:
                    case 0: return new GEN1Fragment();
                    case 1: return new GEN2Fragment();
                    case 2: return new GEN3Fragment();
                }
            }

            @Override
            public int getItemCount() {
                // Número total de pestañas
                return 3;
            }
        });
    }


    private void vincularTabLayoutConViewPager() {
        new TabLayoutMediator(binding.tabLayout, binding.viewPager,
                (tab, position) -> {
                    switch (position) {
                        case 0:
                            tab.setText("GEN I");
                            break;
                        case 1:
                            tab.setText("GEN II");
                            break;
                        case 2:
                            tab.setText("GEN III");
                            break;
                    }
                }).attach();
    }
}
