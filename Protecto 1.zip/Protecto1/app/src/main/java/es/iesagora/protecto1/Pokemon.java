package es.iesagora.protecto1;

import java.io.Serializable;

public class Pokemon implements Serializable {
    private String nombre;
    private int imagen;
    private String Descripcion;

    public Pokemon(String nombre, int imagen, String descripcion) {
        this.nombre = nombre;
        this.imagen = imagen;
        Descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public int getImagen() {
        return imagen;
    }

    public String getDescripcion() {
        return Descripcion;
    }

}
