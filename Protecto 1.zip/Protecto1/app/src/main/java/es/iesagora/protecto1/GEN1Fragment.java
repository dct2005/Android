package es.iesagora.protecto1;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import es.iesagora.protecto1.databinding.FragmentGEN1Binding;
import es.iesagora.protecto1.databinding.FragmentPokedexBinding;


public class GEN1Fragment extends Fragment {
    private FragmentGEN1Binding binding;
    private PokemonRepository repository;
    private PokemonAdapter adapter;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentGEN1Binding.inflate(inflater, container, false);
        return binding.getRoot();
    }
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        repository = new PokemonRepository();
        List<Pokemon> listaAnimales = repository.getGEN1();

        // Configuramos el RecyclerView
        adapter = new PokemonAdapter(requireContext(), listaAnimales);
        binding.recyclerView.setAdapter(adapter);

        // Definimos el LayoutManager (en cuadrícula de 2 columnas)
        binding.recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 2));
    }
}