package es.iesagora.protecto1;

import java.util.ArrayList;
import java.util.List;

public class PokemonRepository {
    private List<Pokemon> listaPokemons;

    public  PokemonRepository() {
        listaPokemons = new ArrayList<>();

        listaPokemons.add(new Pokemon("Max", R.drawable.charmander, "Max es un labrador leal y juguetón."));
        listaPokemons.add(new Pokemon("Luna", R.drawable.charmeleon, "Luna es una gata curiosa y cazadora."));
        listaPokemons.add(new Pokemon("Paco", R.drawable.chaizard, "Paco es un loro que habla mucho."));
        listaPokemons.add(new Pokemon("Spirit", R.drawable.bulbasaur, "Spirit es un caballo fuerte y veloz."));
        listaPokemons.add(new Pokemon("Rocky", R.drawable.ivysaur, "Rocky es un bulldog cariñoso y protector."));
        listaPokemons.add(new Pokemon("Simba", R.drawable.venusair, "Simba es un gato persa muy tranquilo."));
        listaPokemons.add(new Pokemon("Tweety", R.drawable.squirtl, "Tweety es un canario de color amarillo."));
        listaPokemons.add(new Pokemon("Stella", R.drawable.wartortle, "Stella es una yegua amigable y rápida."));
        listaPokemons.add(new Pokemon("Bella", R.drawable.blastoise, "Bella es una golden retriever amistosa."));
    }

    public List<Pokemon> getAnimales() {
        return listaPokemons;
    }
}
