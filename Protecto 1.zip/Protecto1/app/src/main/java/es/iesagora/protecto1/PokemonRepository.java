package es.iesagora.protecto1;

import java.util.ArrayList;
import java.util.List;

public class PokemonRepository {
    private List<Pokemon> listaPokemons;

    private List<Pokemon> listaPokemons1 = new ArrayList<>();
    private List<Pokemon> listaPokemons2 = new ArrayList<>();
    private List<Pokemon> listaPokemons3 = new ArrayList<>();
    private static List<Pokemon> listaEquipo = new ArrayList<>();
    public  PokemonRepository() {
        listaPokemons = new ArrayList<>();

        listaPokemons.add(new Pokemon("Charmander", R.drawable.charmander, "La llama de su cola indica su fuerza vital. Si está débil, la llama arderá más tenue."));
        listaPokemons.add(new Pokemon("Charmeleon", R.drawable.charmeleon, "Al agitar su ardiente cola, eleva poco a poco la temperatura a su alrededor para sofocar a sus rivales."));
        listaPokemons.add(new Pokemon("Charizard", R.drawable.chaizard, "Cuando se enfurece de verdad, la llama de la punta de su cola se vuelve de color azul claro."));
        listaPokemons.add(new Pokemon("Bulbasaur", R.drawable.bulbasaur, "Tras nacer, crece alimentándose durante un tiempo de los nutrientes que contiene el bulbo de su lomo."));
        listaPokemons.add(new Pokemon("Ivysaur", R.drawable.ivysaur, "Cuanta más luz solar recibe, más aumenta su fuerza y más se desarrolla el capullo que tiene en el lomo."));
        listaPokemons.add(new Pokemon("Venusaur", R.drawable.venusair, "Puede convertir la luz del sol en energía. Por esa razón, es más poderoso en verano."));
        listaPokemons.add(new Pokemon("Squirtle", R.drawable.squirtl, "Tras nacer, se le hincha el lomo y se le forma un caparazón. Escupe poderosa espuma por la boca."));
        listaPokemons.add(new Pokemon("Wartortle", R.drawable.wartortle, "Tiene una cola larga y peluda que simboliza la longevidad y lo hace popular entre los mayores."));
        listaPokemons.add(new Pokemon("Blastoise", R.drawable.blastoise, "Aumenta de peso deliberadamente para contrarrestar la fuerza de los chorros de agua que dispara."));
        listaPokemons.add(new Pokemon("Cyndaquil",R.drawable.cynda,"Suele estar encorvado. Si se enfada o se asusta, lanzará llamas por el lomo."));
        listaPokemons.add(new Pokemon("Quilava",R.drawable.quila,"Antes de empezar a luchar, le da la espalda al rival para alardear del alcance y la fuerza de sus llamas."));
        listaPokemons.add(new Pokemon("Typlosion",R.drawable.typlo,"Posee una técnica secreta y devastadora que consiste en atacar frotando su pelaje ardiente para provocar explosiones."));
        listaPokemons.add(new Pokemon("Totodile",R.drawable.totodile,"Sus desarrolladas y potentes mandíbulas pueden triturar cualquier cosa, por lo que hasta su propio Entrenador debe andarse con cuidado."));
        listaPokemons.add(new Pokemon("Croconaw",R.drawable.croco,"Sus colmillos están curvados hacia dentro, por lo que, una vez que muerde a una presa, esta no tiene forma de escapar."));
        listaPokemons.add(new Pokemon("Feraligart",R.drawable.ferali,"Tras morder a su víctima con sus enormes y potentes mandíbulas, agita la cabeza con fuerza para despedazarla."));
        listaPokemons.add(new Pokemon("Chikorita",R.drawable.chikorita,"Le encanta tomar el sol. Usa la hoja que tiene en la cabeza para localizar sitios cálidos."));
        listaPokemons.add(new Pokemon("Bayleef",R.drawable.bayleef,"Su cuello desprende un aroma especiado que, por alguna razón, incita a combatir a quienes lo huelen."));
        listaPokemons.add(new Pokemon("Meganium",R.drawable.meganium,"Estar a su lado produce una sensación de frescor similar a la de un relajante paseo por el bosque."));
        listaPokemons.add(new Pokemon("Treecko",R.drawable.treecko,"Tiene pequeñas púas en las plantas de los pies que le permiten andar por techos y paredes sin caerse."));
        listaPokemons.add(new Pokemon("Grovyle",R.drawable.grovyle,"Los desarrollados músculos de sus extremidades inferiores le proporcionan una tremenda agilidad y una portentosa capacidad de salto."));
        listaPokemons.add(new Pokemon("Sceptile",R.drawable.sceptile,"Corretea ágil y veloz por la selva y emplea las afiladas hojas de sus brazos para darles el golpe de gracia a sus presas."));
        listaPokemons.add(new Pokemon("Mudkip",R.drawable.mudkip,"Puede reducir a añicos grandes rocas. Descansa enterrado en el lodo del lecho de los ríos."));
        listaPokemons.add(new Pokemon("Marshtomp",R.drawable.marshtomp,"Vive en terrenos cubiertos de lodo viscoso, lo que contribuye a que sus patas se fortalezcan y se vuelvan extremadamente robustas."));
        listaPokemons.add(new Pokemon("Swampert",R.drawable.swampert,"Con sus brazos duros como una roca puede partir pedruscos gigantescos en mil pedazos de un solo golpe."));
        listaPokemons.add(new Pokemon("Torchik",R.drawable.torchik,"Posee una saca de fuego en el abdomen, cuya llama arderá durante toda su vida. El calor que desprende resulta muy agradable al abrazarlo."));
        listaPokemons.add(new Pokemon("Combusken",R.drawable.combusken,"Propina unas patadas demoledoras. Profiere potentes gritos para aguzar su concentración."));
        listaPokemons.add(new Pokemon("Blaziken",R.drawable.blaziken,"Ante un rival difícil, expulsa llamas por las muñecas. Tiene mucha fuerza en las patas; hasta puede saltar edificios."));


        listaPokemons3.add(new Pokemon("Treecko",R.drawable.treecko,"Tiene pequeñas púas en las plantas de los pies que le permiten andar por techos y paredes sin caerse."));
        listaPokemons3.add(new Pokemon("Grovyle",R.drawable.grovyle,"Los desarrollados músculos de sus extremidades inferiores le proporcionan una tremenda agilidad y una portentosa capacidad de salto."));
        listaPokemons3.add(new Pokemon("Sceptile",R.drawable.sceptile,"Corretea ágil y veloz por la selva y emplea las afiladas hojas de sus brazos para darles el golpe de gracia a sus presas."));
        listaPokemons3.add(new Pokemon("Mudkip",R.drawable.mudkip,"Puede reducir a añicos grandes rocas. Descansa enterrado en el lodo del lecho de los ríos."));
        listaPokemons3.add(new Pokemon("Marshtomp",R.drawable.marshtomp,"Vive en terrenos cubiertos de lodo viscoso, lo que contribuye a que sus patas se fortalezcan y se vuelvan extremadamente robustas."));
        listaPokemons3.add(new Pokemon("Swampert",R.drawable.swampert,"Con sus brazos duros como una roca puede partir pedruscos gigantescos en mil pedazos de un solo golpe."));
        listaPokemons3.add(new Pokemon("Torchik",R.drawable.torchik,"Posee una saca de fuego en el abdomen, cuya llama arderá durante toda su vida. El calor que desprende resulta muy agradable al abrazarlo."));
        listaPokemons3.add(new Pokemon("Combusken",R.drawable.combusken,"Propina unas patadas demoledoras. Profiere potentes gritos para aguzar su concentración."));
        listaPokemons3.add(new Pokemon("Blaziken",R.drawable.blaziken,"Ante un rival difícil, expulsa llamas por las muñecas. Tiene mucha fuerza en las patas; hasta puede saltar edificios."));

        listaPokemons2.add(new Pokemon("Cyndaquil",R.drawable.cynda,"Suele estar encorvado. Si se enfada o se asusta, lanzará llamas por el lomo."));
        listaPokemons2.add(new Pokemon("Quilava",R.drawable.quila,"Antes de empezar a luchar, le da la espalda al rival para alardear del alcance y la fuerza de sus llamas."));
        listaPokemons2.add(new Pokemon("Typlosion",R.drawable.typlo,"Posee una técnica secreta y devastadora que consiste en atacar frotando su pelaje ardiente para provocar explosiones."));
        listaPokemons2.add(new Pokemon("Totodile",R.drawable.totodile,"Sus desarrolladas y potentes mandíbulas pueden triturar cualquier cosa, por lo que hasta su propio Entrenador debe andarse con cuidado."));
        listaPokemons2.add(new Pokemon("Croconaw",R.drawable.croco,"Sus colmillos están curvados hacia dentro, por lo que, una vez que muerde a una presa, esta no tiene forma de escapar."));
        listaPokemons2.add(new Pokemon("Feraligart",R.drawable.ferali,"Tras morder a su víctima con sus enormes y potentes mandíbulas, agita la cabeza con fuerza para despedazarla."));
        listaPokemons2.add(new Pokemon("Chikorita",R.drawable.chikorita,"Le encanta tomar el sol. Usa la hoja que tiene en la cabeza para localizar sitios cálidos."));
        listaPokemons2.add(new Pokemon("Bayleef",R.drawable.bayleef,"Su cuello desprende un aroma especiado que, por alguna razón, incita a combatir a quienes lo huelen."));
        listaPokemons2.add(new Pokemon("Meganium",R.drawable.meganium,"Estar a su lado produce una sensación de frescor similar a la de un relajante paseo por el bosque."));

        listaPokemons1.add(new Pokemon("Charmander", R.drawable.charmander, "La llama de su cola indica su fuerza vital. Si está débil, la llama arderá más tenue."));
        listaPokemons1.add(new Pokemon("Charmeleon", R.drawable.charmeleon, "Al agitar su ardiente cola, eleva poco a poco la temperatura a su alrededor para sofocar a sus rivales."));
        listaPokemons1.add(new Pokemon("Charizard", R.drawable.chaizard, "Cuando se enfurece de verdad, la llama de la punta de su cola se vuelve de color azul claro."));
        listaPokemons1.add(new Pokemon("Bulbasaur", R.drawable.bulbasaur, "Tras nacer, crece alimentándose durante un tiempo de los nutrientes que contiene el bulbo de su lomo."));
        listaPokemons1.add(new Pokemon("Ivysaur", R.drawable.ivysaur, "Cuanta más luz solar recibe, más aumenta su fuerza y más se desarrolla el capullo que tiene en el lomo."));
        listaPokemons1.add(new Pokemon("Venusaur", R.drawable.venusair, "Puede convertir la luz del sol en energía. Por esa razón, es más poderoso en verano."));
        listaPokemons1.add(new Pokemon("Squirtle", R.drawable.squirtl, "Tras nacer, se le hincha el lomo y se le forma un caparazón. Escupe poderosa espuma por la boca."));
        listaPokemons1.add(new Pokemon("Wartortle", R.drawable.wartortle, "Tiene una cola larga y peluda que simboliza la longevidad y lo hace popular entre los mayores."));
        listaPokemons1.add(new Pokemon("Blastoise", R.drawable.blastoise, "Aumenta de peso deliberadamente para contrarrestar la fuerza de los chorros de agua que dispara."));
    }
public void aniadirpokemon(Pokemon pokemon){
        listaEquipo.add(pokemon);
}
    public List<Pokemon> getAnimales() {
        return listaPokemons;
    }
    public List<Pokemon> getEquipo() {
        return listaEquipo;
    }

    public List<Pokemon> getGEN1() {
        return listaPokemons1;
    }

    public List<Pokemon> getGEN2() {
        return listaPokemons2;
    }

    public List<Pokemon> getGEN3() {
        return listaPokemons3;
    }
}
