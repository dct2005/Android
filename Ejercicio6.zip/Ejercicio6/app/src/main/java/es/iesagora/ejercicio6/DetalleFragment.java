package es.iesagora.ejercicio6;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import es.iesagora.ejercicio6.databinding.FragmentDetalleBinding;

public class DetalleFragment extends Fragment {

    private Pokemon pokemon;
    private FragmentDetalleBinding binding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Recuperamos el argumento enviado desde el adapter (antes de crear la vista)
        if (getArguments() != null) {
            pokemon = (Pokemon) getArguments().getSerializable("pokemon");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentDetalleBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (pokemon != null) {
            // Mostramos los datos del pokemon en la interfaz
            binding.tvNombreDetalle.setText(pokemon.getNombre());
            binding.ivDetalle.setImageResource(pokemon.getImagen());
            binding.tvDescripcion.setText(pokemon.getDescripcion());
        } else {
            // En caso de error, podríamos volver atrás o mostrar un mensaje
            Toast.makeText(requireContext(), "No se pudo cargar el detalle del pokemon", Toast.LENGTH_SHORT).show();
            requireActivity().onBackPressed();
        }
    }
}