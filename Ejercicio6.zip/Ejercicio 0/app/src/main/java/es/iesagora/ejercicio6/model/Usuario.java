package es.iesagora.ejercicio6.model;

import java.util.List;

public class Usuario {
    public String nombre;
    public String email;
    public int edad;
    public List<Integer> generosFavoritos;
    private String fotoPerfil;
    private String uid;

    public Usuario() {}

    public Usuario(String nombre, String email, int edad, List<Integer> generosFavoritos, String uid, String fotoPerfil) {
        this.nombre = nombre;
        this.email = email;
        this.edad = edad;
        this.generosFavoritos = generosFavoritos;
        this.fotoPerfil = fotoPerfil;
        this.uid = uid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(String fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public List<Integer> getGenerosFavoritos() {
        return generosFavoritos;
    }

    public void setGenerosFavoritos(List<Integer> generosFavoritos) {
        this.generosFavoritos = generosFavoritos;
    }
}
