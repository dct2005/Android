package es.iesagora.ejercicio6.model;

import com.google.firebase.firestore.ServerTimestamp;

import java.util.Date;

public class Comentario {
    private String id;
    private String idAutor;
    private String nombre;
    private String texto;
    @ServerTimestamp
    private Date timestamp;

    public Comentario() {}


    public Comentario(String nombre, String texto, String idAutor) {
        this.nombre = nombre;
        this.texto = texto;
        this.idAutor = idAutor;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getIdAutor() { return idAutor; }
    public void setIdAutor(String idAutor) { this.idAutor = idAutor; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTexto() { return texto; }
    public void setTexto(String texto) { this.texto = texto; }

    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
}