package es.iesagora.ejercicio6.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PeliculaDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insertar(PeliculaySerie peliculaySerie);

    @Update
    void actualizar(PeliculaySerie peliculaySerie);

    @Delete
    void eliminar(PeliculaySerie peliculaySerie);

    @Query("SELECT * FROM PeliculaySerie ORDER BY titulo ASC")
    LiveData<List<PeliculaySerie>> obtenerTodos();

    @Query("SELECT * FROM PeliculaySerie WHERE titulo = :titulo LIMIT 1")
    LiveData<PeliculaySerie> buscarPorNombre(String titulo);
}
