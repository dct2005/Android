package es.iesagora.ejercicio6;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;

import es.iesagora.ejercicio6.CatalogoViewModel;
import es.iesagora.ejercicio6.databinding.FragmentDetalleSeguimientoBinding;

public class DetalleSeguimientoFragment extends Fragment {
    private FragmentDetalleSeguimientoBinding binding;
    private CatalogoViewModel viewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return (binding = FragmentDetalleSeguimientoBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);

        viewModel.getSeguimientoSeleccionado().observe(getViewLifecycleOwner(), seguimiento -> {
            if (seguimiento != null) {
                binding.tvTituloDetalle.setText(seguimiento.getTitulo());
                binding.tvFechaDetalle.setText("Fecha: " + seguimiento.getFecha());
                binding.ratingBarDetalle.setRating(seguimiento.getPuntuacion());


                if (seguimiento.getFoto() != null && !seguimiento.getFoto().isEmpty()) {
                    Glide.with(this)
                            .load(seguimiento.getFoto())
                            .placeholder(android.R.drawable.ic_menu_gallery)
                            .error(android.R.drawable.stat_notify_error)
                            .into(binding.imgPosterDetalle);
                } else {
                    binding.imgPosterDetalle.setImageResource(android.R.drawable.ic_menu_gallery);
                }
            }
        });
    }
}