package es.iesagora.ejercicio6;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import es.iesagora.ejercicio6.databinding.FragmentRegistroBinding;


public class RegistroFragment extends Fragment {

    private FragmentRegistroBinding binding;
    private CatalogoViewModel viewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentRegistroBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);

        setupAuthStateObserver();

        binding.btnCrearCuenta.setOnClickListener(v -> {
            String email = binding.etEmail.getText().toString().trim();
            String pass = binding.etPassword.getText().toString().trim();
            String confirmPass = binding.etConfirmPassword.getText().toString().trim();


            viewModel.register(email, pass, confirmPass);
        });

        binding.tvIniciaSesion.setOnClickListener(v -> {
            Navigation.findNavController(v).navigateUp();
        });

        binding.btnGoogle.setOnClickListener(v -> {
            // Lógica para Continuar con Google
        });
    }

    private void setupAuthStateObserver() {
        viewModel.getAuthState().observe(getViewLifecycleOwner(), state -> {
            if (state == null) return;

            if (state.isError()) {

                Toast.makeText(getContext(), state.getMessage(), Toast.LENGTH_LONG).show();
            }

            if (state.isSuccess()) {

                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
                getActivity().finish();
            }
        });
    }
}