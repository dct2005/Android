package es.iesagora.ejercicio6;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.ejercicio6.databinding.FragmentRegistroBinding;

public class RegistroFragment extends Fragment {

    private FragmentRegistroBinding binding;
    private Uri uriFotoSeleccionada;
    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    uriFotoSeleccionada = result.getData().getData();

                    binding.ivFotoPerfil.setImageURI(uriFotoSeleccionada);
                }
            }
    );
    private GoogleSignInClient googleSignInClient;
    private CatalogoViewModel viewModel;

    private final String[] nombresGeneros = {"Acción", "Terror", "Comedia", "Ciencia Ficción", "Drama", "Romance"};
    private final int[] idsGeneros = {28, 27, 35, 878, 18, 10749};
    private final boolean[] seleccionados = new boolean[nombresGeneros.length];
    private final List<Integer> generosElegidosIds = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentRegistroBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);

        setupAuthStateObserver();


        binding.btnSeleccionarGeneros.setOnClickListener(v -> mostrarDialogoGeneros());


        binding.btnCrearCuenta.setOnClickListener(v -> {
            String nombre = binding.etNombre.getText().toString().trim();
            String email = binding.etEmail.getText().toString().trim();
            String pass = binding.etPassword.getText().toString().trim();
            String confirmPass = binding.etConfirmPassword.getText().toString().trim();
            String edadStr = binding.etEdad.getText().toString().trim();


            if (nombre.isEmpty() || email.isEmpty() || pass.isEmpty() || edadStr.isEmpty()) {
                Toast.makeText(getContext(), "Por favor, rellena todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            int edad = Integer.parseInt(edadStr);


            viewModel.register(nombre, email, pass, confirmPass, edad, generosElegidosIds,uriFotoSeleccionada);
        });

        binding.tvIniciaSesion.setOnClickListener(v -> {
            Navigation.findNavController(v).navigateUp();
        });


        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(requireActivity(), gso);

        binding.btnGoogle.setOnClickListener(v -> {
            Intent signInIntent = googleSignInClient.getSignInIntent();
            launcher.launch(signInIntent);
        });

        binding.ivFotoPerfil.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            galleryLauncher.launch(intent);
        });
    }


    private void mostrarDialogoGeneros() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("¿Qué géneros te gustan?");

        builder.setMultiChoiceItems(nombresGeneros, seleccionados, (dialog, which, isChecked) -> {
            if (isChecked) {
                generosElegidosIds.add(idsGeneros[which]);
            } else {
                generosElegidosIds.remove(Integer.valueOf(idsGeneros[which]));
            }
        });

        builder.setPositiveButton("Aceptar", (dialog, which) -> {
            if (generosElegidosIds.isEmpty()) {
                binding.btnSeleccionarGeneros.setText("Elegir géneros favoritos");
            } else {
                binding.btnSeleccionarGeneros.setText("Géneros seleccionados: " + generosElegidosIds.size());
            }
        });

        builder.show();
    }

    private void setupAuthStateObserver() {
        viewModel.getAuthState().observe(getViewLifecycleOwner(), state -> {
            if (state == null) return;

            if (state.isError()) {
                Toast.makeText(getContext(), state.getMessage(), Toast.LENGTH_LONG).show();
            }

            if (state.isSuccess()) {
                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
                getActivity().finish();
            }
        });
    }

    private final ActivityResultLauncher<Intent> launcher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(result.getData());
                    try {
                        GoogleSignInAccount account = task.getResult(ApiException.class);
                        if (account != null) {
                            viewModel.loginConGoogle(account.getIdToken());
                        }
                    } catch (ApiException e) {
                        Toast.makeText(getContext(), "Error Google: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );
}