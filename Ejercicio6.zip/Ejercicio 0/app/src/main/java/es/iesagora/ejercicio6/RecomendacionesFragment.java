package es.iesagora.ejercicio6;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import es.iesagora.ejercicio6.databinding.FragmentRecomendacionesBinding;

public class RecomendacionesFragment extends Fragment {

    private FragmentRecomendacionesBinding binding;
    private CatalogoViewModel viewModel;
    private CatalogoAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentRecomendacionesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);
        viewModel.cargarDatosUsuario();

        binding.recyclerPersonalizado.setLayoutManager(new LinearLayoutManager(getContext()));


        adapter = new CatalogoAdapter(getContext(), viewModel);
        binding.recyclerPersonalizado.setAdapter(adapter);

        setupObservers();


        viewModel.cargarPeliculasPersonalizadas();
    }

    private void setupObservers() {
        viewModel.Peliculas.observe(getViewLifecycleOwner(), resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case LOADING:
                    binding.progressLoadingPersonalizado.setVisibility(View.VISIBLE);
                    binding.layoutErrorPersonalizado.setVisibility(View.GONE);
                    break;

                case SUCCESS:
                    binding.progressLoadingPersonalizado.setVisibility(View.GONE);
                    if (resource.data != null && !resource.data.isEmpty()) {

                        adapter.addPeliculaList(resource.data);
                        binding.layoutErrorPersonalizado.setVisibility(View.GONE);
                    } else {
                        binding.layoutErrorPersonalizado.setVisibility(View.VISIBLE);
                    }
                    break;

                case ERROR:
                    binding.progressLoadingPersonalizado.setVisibility(View.GONE);
                    binding.layoutErrorPersonalizado.setVisibility(View.VISIBLE);
                    binding.tvErrorPersonalizado.setText(resource.message);
                    break;
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}