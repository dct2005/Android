package es.iesagora.ejercicio6;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import es.iesagora.ejercicio6.databinding.FragmentSeguimientoBinding;


public class SeguimientoFragment extends Fragment {
    FragmentSeguimientoBinding binding;
    private NavController navController;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return (binding = FragmentSeguimientoBinding.inflate(inflater, container, false)).getRoot();
    }
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);


        CatalogoViewModel viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);


        CatalogoAdapter adapter = new CatalogoAdapter(requireContext(),viewModel);
        binding.recyclerViewAnimales.setAdapter(adapter);


        viewModel.ObtenerSerie().observe(getViewLifecycleOwner(), lista -> {
            if (lista != null && !lista.isEmpty()) {

                binding.recyclerViewAnimales.setVisibility(View.VISIBLE);
                binding.layoutVacio.setVisibility(View.GONE);
                adapter.establecerListaSeguimiento(lista);
            } else {

                binding.recyclerViewAnimales.setVisibility(View.GONE);
                binding.layoutVacio.setVisibility(View.VISIBLE);
            }
        });


        binding.fabAgregarAnimal.setOnClickListener(v ->
                navController.navigate(R.id.action_seguimientoFragment_to_aniadirFragment)
        );
}
    }