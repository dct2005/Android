package es.iesagora.ejercicio6;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import java.util.ArrayList;

import es.iesagora.ejercicio6.databinding.FragmentSeguimientoBinding;

public class SeguimientoFragment extends Fragment {
    private FragmentSeguimientoBinding binding;
    private NavController navController;
    private CatalogoViewModel viewModel;
    private CatalogoAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return (binding = FragmentSeguimientoBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        navController = Navigation.findNavController(view);
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);

        adapter = new CatalogoAdapter(requireContext(), viewModel);
        binding.recyclerViewAnimales.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(getContext()));
        binding.recyclerViewAnimales.setAdapter(adapter);


        viewModel.getListaSeguimiento().observe(getViewLifecycleOwner(), lista -> {
            if (lista == null || lista.isEmpty()) {
                binding.recyclerViewAnimales.setVisibility(View.GONE);
                binding.layoutVacio.setVisibility(View.VISIBLE);
            } else {
                binding.recyclerViewAnimales.setVisibility(View.VISIBLE);
                binding.layoutVacio.setVisibility(View.GONE);
                adapter.establecerListaSeguimiento(lista);
            }
        });


        viewModel.filtrarSeguimiento("", null, null, null, null, "titulo", true);

        configurarFiltros();

        binding.fabAgregarAnimal.setOnClickListener(v ->
                navController.navigate(R.id.action_seguimientoFragment_to_aniadirFragment)
        );
    }

    private void configurarFiltros() {
        binding.searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                actualizarLista(s.toString(), null, null, null, null, "titulo", true);
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        binding.btnOrdenar.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(getContext(), v);
            popup.getMenu().add("Fecha (Más reciente)");
            popup.getMenu().add("Puntuación (Mayor a menor)");
            popup.getMenu().add("Título (A-Z)");

            popup.setOnMenuItemClickListener(item -> {
                String titulo = binding.searchBar.getText().toString();
                switch (item.getTitle().toString()) {
                    case "Fecha (Más reciente)":
                        actualizarLista(titulo, null, null, null, null, "fecha", false);
                        break;
                    case "Puntuación (Mayor a menor)":
                        actualizarLista(titulo, null, null, null, null, "puntuacion", false);
                        break;
                    case "Título (A-Z)":
                        actualizarLista(titulo, null, null, null, null, "titulo", true);
                        break;
                }
                return true;
            });
            popup.show();
        });

        binding.btnFiltros.setOnClickListener(v -> mostrarDialogoFiltrosAvanzados());
    }

    private void mostrarDialogoFiltrosAvanzados() {
        View view = getLayoutInflater().inflate(R.layout.dialog_filtros, null);

        EditText etMin = view.findViewById(R.id.etMinPuntos);
        EditText etMax = view.findViewById(R.id.etMaxPuntos);
        EditText etFInicio = view.findViewById(R.id.etFechaInicio);
        EditText etFFin = view.findViewById(R.id.etFechaFin);


        etFInicio.setOnClickListener(v -> mostrarCalendario(etFInicio));

        etFFin.setOnClickListener(v -> mostrarCalendario(etFFin));

        new AlertDialog.Builder(getContext())
                .setTitle("Filtros de búsqueda")
                .setView(view)
                .setPositiveButton("Aplicar", (dialog, which) -> {
                    String minS = etMin.getText().toString();
                    String maxS = etMax.getText().toString();
                    String fInicio = etFInicio.getText().toString();
                    String fFin = etFFin.getText().toString();

                    Float min = minS.isEmpty() ? null : Float.parseFloat(minS);
                    Float max = maxS.isEmpty() ? null : Float.parseFloat(maxS);

                    if (min != null && max != null && min > max) {
                        Toast.makeText(getContext(), "El mínimo no puede ser mayor al máximo", Toast.LENGTH_SHORT).show();
                    } else {
                        actualizarLista(binding.searchBar.getText().toString(), min, max, fInicio, fFin, "titulo", true);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }


    private void mostrarCalendario(EditText editText) {
        java.util.Calendar calendar = java.util.Calendar.getInstance();
        int año = calendar.get(java.util.Calendar.YEAR);
        int mes = calendar.get(java.util.Calendar.MONTH);
        int dia = calendar.get(java.util.Calendar.DAY_OF_MONTH);

        android.app.DatePickerDialog picker = new android.app.DatePickerDialog(getContext(), (view, year, month, dayOfMonth) -> {

            String fechaSeleccionada = String.format("%04d-%02d-%02d", year, (month + 1), dayOfMonth);
            editText.setText(fechaSeleccionada);
        }, año, mes, dia);

        picker.show();
    }

    private void actualizarLista(String titulo, Float min, Float max, String inicio, String fin, String campo, boolean asc) {
        viewModel.filtrarSeguimiento(titulo, min, max, inicio, fin, campo, asc);
    }

}