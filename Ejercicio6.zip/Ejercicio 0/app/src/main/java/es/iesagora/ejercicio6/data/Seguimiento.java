package es.iesagora.ejercicio6.data;



import java.util.Date;


public class Seguimiento {

    private int id;

    private String tipo;
    private String titulo;
    private String fecha;
    private float puntuacion;
    private String foto;

    public Seguimiento() {}

    public Seguimiento(String tipo, String titulo, String fecha, float puntuacion, String foto) {
        this.tipo = tipo;
        this.titulo = titulo;
        this.fecha = fecha;
        this.puntuacion = puntuacion;
        this.foto = foto;
    }


    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public float getPuntuacion() { return puntuacion; }
    public void setPuntuacion(float puntuacion) { this.puntuacion = puntuacion; }
}