package es.iesagora.ejercicio6.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "Seguimiento")
public class Seguimiento {
    @PrimaryKey (autoGenerate = true)
    private int id;

    private String tipo;
    private String titulo;
  private String fecha;
    private float puntuacion;

    private byte[] foto;

    public String getFecha() {
        return fecha;
    }

    public Seguimiento(String tipo, String titulo, String fecha, float puntuacion, byte[] foto) {
        this.tipo = tipo;
        this.titulo = titulo;
 this.fecha = fecha;
        this.puntuacion = puntuacion;
        this.foto = foto;
    }


    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

  //  public Date getFecha() {
 //       return fecha;
 //   }

   // public void setFecha(Date fecha) {
    //    this.fecha = fecha;
   // }

    public float getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }





    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }
}
