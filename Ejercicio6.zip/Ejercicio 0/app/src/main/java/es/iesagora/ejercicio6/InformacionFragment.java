package es.iesagora.ejercicio6;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import es.iesagora.ejercicio6.databinding.FragmentInformacionBinding;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class InformacionFragment extends Fragment {
    private FragmentInformacionBinding binding;
    private CatalogoViewModel viewModel;
    private DigiApi service;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentInformacionBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        service = RetrofitClient.getClient().create(DigiApi.class);
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);




        viewModel.Peliseleccionada.observe(getViewLifecycleOwner(), pelicula -> {
            if (pelicula != null) {

                binding.tvNombreDetalle.setText(pelicula.getTitle());
                binding.tvDescripcion.setText(pelicula.getOverview());


                if (pelicula.getPosterPath() != null) {
                    Glide.with(this)
                            .load("https://image.tmdb.org/t/p/w500" + pelicula.getPosterPath())
                            .into(binding.ivDetalle);
                }



                String idPelicula = String.valueOf(pelicula.getId());

                Call<Result> call = service.getDetallesPelicula(idPelicula);




                call.enqueue(new Callback<Result>() {
                    @Override
                    public void onResponse(Call<Result> call, Response<Result> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Result peliculaCompleta = response.body();

                            binding.layoutGenres.removeAllViews();

                            if (peliculaCompleta.getGenres() != null) {
                                for(Result.Genre g : peliculaCompleta.getGenres()){
                                    TextView nuevoTexto = new TextView(requireContext());


                                    nuevoTexto.setText(g.getName());


                                    nuevoTexto.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);


                                    nuevoTexto.setTextColor(Color.parseColor("#555555"));


                                    nuevoTexto.setBackgroundColor(Color.parseColor("#EEEEEE"));


                                    float escala = getResources().getDisplayMetrics().density;
                                    int paddingH = (int) (12 * escala + 0.5f);
                                    int paddingV = (int) (6 * escala + 0.5f);


                                    nuevoTexto.setPadding(paddingH, paddingV, paddingH, paddingV);


                                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                            ViewGroup.LayoutParams.WRAP_CONTENT,
                                            ViewGroup.LayoutParams.WRAP_CONTENT
                                    );



                                    int margin = (int) (4 * escala + 0.5f);
                                    params.setMargins(margin, margin, margin, margin);


                                    nuevoTexto.setLayoutParams(params);
                                    binding.layoutGenres.addView(nuevoTexto);
                                }
                            }
                            String urlReal = peliculaCompleta.getHomepage();


                            binding.btnTrailer.setOnClickListener(v -> {
                                if (urlReal != null && !urlReal.isEmpty()) {
                                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlReal));
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(getContext(), "Sin web oficial", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailure(Call<Result> call, Throwable t) {

                    }
                });
            }
        });


        viewModel.SerieSeleccionada.observe(getViewLifecycleOwner(), serie -> {
            if (serie != null) {

                binding.tvNombreDetalle.setText(serie.getName());
                binding.tvDescripcion.setText(serie.getOverview());

                if (serie.getPosterPath() != null) {
                    Glide.with(this)
                            .load("https://image.tmdb.org/t/p/w500" + serie.getPosterPath())
                            .into(binding.ivDetalle);
                }



                String idSerie = String.valueOf(serie.getId());

                Call<Result2> callSerie = service.getDetallesSerie(idSerie);

                callSerie.enqueue(new Callback<Result2>() {
                    @Override
                    public void onResponse(Call<Result2> call, Response<Result2> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Result2 peliculaCompleta = response.body();
                            String urlReal = peliculaCompleta.getHomepage();
                            if (peliculaCompleta.getGenres() != null) {
                                for(Result2.Genre g : peliculaCompleta.getGenres()){
                                    TextView nuevoTexto = new TextView(requireContext());


                                    nuevoTexto.setText(g.getName());


                                    nuevoTexto.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);


                                    nuevoTexto.setTextColor(Color.parseColor("#555555"));


                                    nuevoTexto.setBackgroundColor(Color.parseColor("#EEEEEE"));


                                    float escala = getResources().getDisplayMetrics().density;
                                    int paddingH = (int) (12 * escala + 0.5f);
                                    int paddingV = (int) (6 * escala + 0.5f);


                                    nuevoTexto.setPadding(paddingH, paddingV, paddingH, paddingV);


                                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                            ViewGroup.LayoutParams.WRAP_CONTENT,
                                            ViewGroup.LayoutParams.WRAP_CONTENT
                                    );



                                    int margin = (int) (4 * escala + 0.5f);
                                    params.setMargins(margin, margin, margin, margin);


                                    nuevoTexto.setLayoutParams(params);
                                    binding.layoutGenres.addView(nuevoTexto);
                                }
                            }

                            binding.btnTrailer.setOnClickListener(v -> {
                                if (urlReal != null && !urlReal.isEmpty()) {
                                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlReal));
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(getContext(), "Sin web oficial", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailure(Call<Result2> call, Throwable t) {

                    }
                });
            }
        });

    }
}



