package es.iesagora.ejercicio6;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;

import es.iesagora.ejercicio6.databinding.FragmentInformacionBinding;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InformacionFragment extends Fragment {

    private FragmentInformacionBinding binding;
    private CatalogoViewModel viewModel;
    private ComentsViewModel viewModelComentarios;
    private DigiApi service;
    private ComentariosAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentInformacionBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        service = RetrofitClient.getClient().create(DigiApi.class);
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);
        viewModelComentarios = new ViewModelProvider(this).get(ComentsViewModel.class);

        adapter = new ComentariosAdapter(comentario -> {
            new androidx.appcompat.app.AlertDialog.Builder(requireContext())
                    .setTitle("Eliminar comentario")
                    .setMessage("¿Estás seguro de que quieres borrar este comentario?")
                    .setPositiveButton("Borrar", (dialog, which) -> {
                        viewModelComentarios.eliminarComentario(comentario.getId());
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });

        binding.rvComentarios.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.rvComentarios.setAdapter(adapter);

        viewModel.getYaExisteEnLista().observe(getViewLifecycleOwner(), existe -> {
            if (existe) {
                Toast.makeText(getContext(), "¡Ya tienes este título guardado!", Toast.LENGTH_LONG).show();
            }
        });

        viewModelComentarios.getComentarios().observe(getViewLifecycleOwner(), resource -> {
            if (resource.status == Resource.Status.SUCCESS && resource.data != null) {
                adapter.setLista(resource.data);

                if (resource.data.isEmpty()) {
                    binding.tvEmptyState.setVisibility(View.VISIBLE);
                    binding.rvComentarios.setVisibility(View.GONE);
                } else {
                    binding.tvEmptyState.setVisibility(View.GONE);
                    binding.rvComentarios.setVisibility(View.VISIBLE);
                }
            } else if (resource.status == Resource.Status.ERROR) {
                Toast.makeText(getContext(), "Error al cargar comentarios", Toast.LENGTH_SHORT).show();
            }
        });

        viewModel.Peliseleccionada.observe(getViewLifecycleOwner(), pelicula -> {
            if (pelicula != null) {
                binding.tvNombreDetalle.setText(pelicula.getTitle());
                binding.tvDescripcion.setText(pelicula.getOverview());

                if (pelicula.getPosterPath() != null) {
                    Glide.with(this)
                            .load("https://image.tmdb.org/t/p/w500" + pelicula.getPosterPath())
                            .into(binding.ivDetalle);
                }

                String idPelicula = String.valueOf(pelicula.getId());

                viewModel.comprobarExistencia(idPelicula, true);
                viewModelComentarios.cargarComentarios(idPelicula);

                binding.btnEnviar.setOnClickListener(v -> {
                    String texto = binding.etComentario.getText().toString();
                    if (!texto.trim().isEmpty()) {
                        viewModelComentarios.agregarComentario(texto);
                        binding.etComentario.setText("");
                    }
                });

                Call<Result> call = service.getDetallesPelicula(idPelicula);
                call.enqueue(new Callback<Result>() {
                    @Override
                    public void onResponse(@NonNull Call<Result> call, @NonNull Response<Result> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Result peliculaCompleta = response.body();

                            binding.layoutGenres.removeAllViews();

                            if (peliculaCompleta.getGenres() != null) {
                                for (Result.Genre g : peliculaCompleta.getGenres()) {
                                    crearChipGenero(g.getName());
                                }
                            }

                            String urlReal = peliculaCompleta.getHomepage();
                            binding.btnTrailer.setOnClickListener(v -> {
                                if (urlReal != null && !urlReal.isEmpty()) {
                                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlReal));
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(getContext(), "Sin web oficial", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<Result> call, @NonNull Throwable t) {
                    }
                });
            }
        });

        viewModel.SerieSeleccionada.observe(getViewLifecycleOwner(), serie -> {
            if (serie != null) {
                binding.tvNombreDetalle.setText(serie.getName());
                binding.tvDescripcion.setText(serie.getOverview());

                if (serie.getPosterPath() != null) {
                    Glide.with(this)
                            .load("https://image.tmdb.org/t/p/w500" + serie.getPosterPath())
                            .into(binding.ivDetalle);
                }

                String idSerie = String.valueOf(serie.getId());

                viewModel.comprobarExistencia(idSerie, false);
                viewModelComentarios.cargarComentarios(idSerie);

                binding.btnEnviar.setOnClickListener(v -> {
                    String texto = binding.etComentario.getText().toString();
                    if (!texto.trim().isEmpty()) {
                        viewModelComentarios.agregarComentario(texto);
                        binding.etComentario.setText("");
                    }
                });

                Call<Result2> callSerie = service.getDetallesSerie(idSerie);
                callSerie.enqueue(new Callback<Result2>() {
                    @Override
                    public void onResponse(@NonNull Call<Result2> call, @NonNull Response<Result2> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Result2 serieCompleta = response.body();

                            binding.layoutGenres.removeAllViews();

                            if (serieCompleta.getGenres() != null) {
                                for (Result2.Genre g : serieCompleta.getGenres()) {
                                    crearChipGenero(g.getName());
                                }
                            }

                            String urlReal = serieCompleta.getHomepage();
                            binding.btnTrailer.setOnClickListener(v -> {
                                if (urlReal != null && !urlReal.isEmpty()) {
                                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(urlReal));
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(getContext(), "Sin web oficial", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<Result2> call, @NonNull Throwable t) {
                    }
                });
            }
        });
    }

    private void crearChipGenero(String nombreGenero) {
        TextView nuevoTexto = new TextView(requireContext());
        nuevoTexto.setText(nombreGenero);
        nuevoTexto.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        nuevoTexto.setTextColor(Color.parseColor("#555555"));
        nuevoTexto.setBackgroundColor(Color.parseColor("#EEEEEE"));

        float escala = getResources().getDisplayMetrics().density;
        int paddingH = (int) (12 * escala + 0.5f);
        int paddingV = (int) (6 * escala + 0.5f);
        nuevoTexto.setPadding(paddingH, paddingV, paddingH, paddingV);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        int margin = (int) (4 * escala + 0.5f);
        params.setMargins(margin, margin, margin, margin);

        nuevoTexto.setLayoutParams(params);
        binding.layoutGenres.addView(nuevoTexto);
    }
}