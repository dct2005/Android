package es.iesagora.ejercicio6;

import okhttp3.*;
import java.io.IOException;

public class SupabaseStorage {
    private static final String URL_SUPABASE = "https://skeceyvvytlwjyrmlsik.supabase.co";
    private static final String ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNrZWNleXZ2eXRsd2p5cm1sc2lrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI3MDk3MzcsImV4cCI6MjA4ODI4NTczN30.37rlx_MPSuBNpMR6zvAFiNRSyldJoOSD3kFnlF-zqRM";
    private static final String BUCKET_NAME = "seguimiento";

    public interface UploadCallback {
        void onSuccess(String imageUrl);
        void onError(String message);
    }

    public static void subirImagen(byte[] imagen, String fileName, UploadCallback callback) {
        OkHttpClient client = new OkHttpClient();

        RequestBody body = RequestBody.create(MediaType.parse("image/jpeg"), imagen);
        Request request = new Request.Builder()
                .url(URL_SUPABASE + "/storage/v1/object/" + BUCKET_NAME + "/" + fileName)
                .post(body)
                .addHeader("Authorization", "Bearer " + ANON_KEY)
                .addHeader("apikey", ANON_KEY)
                .addHeader("Content-Type", "image/jpeg")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onError(e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {

                    String publicUrl = URL_SUPABASE + "/storage/v1/object/public/" + BUCKET_NAME + "/" + fileName;
                    callback.onSuccess(publicUrl);
                } else {
                    callback.onError("Error en respuesta: " + response.code());
                }
            }
        });
    }
}