package es.iesagora.ejercicio6;
import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
public class AuthInterceptor implements Interceptor{
     private static final String MI_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmMjRiMGNiZTAxNDFiOWE1YTQyZmNmZDQ2OGY3N2M0OCIsIm5iZiI6MTc2Nzg4NzAzMy43MjMsInN1YiI6IjY5NWZkMGI5NTVlODVlMDliYmM5NzJlYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.s5ZDbKugwmJqE9KxVfE7i4HWbg60KepzhqM74-NX0ss";

    @Override
    public Response intercept(Interceptor.Chain chain) throws IOException {

        Request requestOriginal = chain.request();


        Request requestConToken = requestOriginal.newBuilder()
                .header("Authorization", "Bearer " + MI_TOKEN)
                .build();


        return chain.proceed(requestConToken);
    }
}
