package es.iesagora.ejercicio6;
import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
public class AuthInterceptor implements Interceptor{
    // Pega tu token largo aquí (en una app real iría en local.properties, pero para aprender vale aquí)
    private static final String MI_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJmMjRiMGNiZTAxNDFiOWE1YTQyZmNmZDQ2OGY3N2M0OCIsIm5iZiI6MTc2Nzg4NzAzMy43MjMsInN1YiI6IjY5NWZkMGI5NTVlODVlMDliYmM5NzJlYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.s5ZDbKugwmJqE9KxVfE7i4HWbg60KepzhqM74-NX0ss";

    @Override
    public Response intercept(Interceptor.Chain chain) throws IOException {
        // 1. Agarramos la petición original que iba a salir (sin token)
        Request requestOriginal = chain.request();

        // 2. Creamos una nueva petición idéntica, pero agregando la cabecera
        Request requestConToken = requestOriginal.newBuilder()
                .header("Authorization", "Bearer " + MI_TOKEN) // OJO: Espacio después de Bearer
                .build();

        // 3. Dejamos pasar la nueva petición con el token
        return chain.proceed(requestConToken);
    }
}
