package es.iesagora.ejercicio6;

import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import java.util.ArrayList;
import java.util.List;
import es.iesagora.ejercicio6.model.Comentario;

public class ComentariosAdapter extends RecyclerView.Adapter<ComentariosAdapter.ViewHolder> {

    private List<Comentario> lista;
    private final String miId;
    private OnComentarioLongClickListener listener;

    public interface OnComentarioLongClickListener {
        void onLongClick(Comentario c);
    }

    public ComentariosAdapter(OnComentarioLongClickListener listener) {
        this.lista = new ArrayList<>();
        this.listener = listener;
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            this.miId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        } else {
            this.miId = "";
        }
    }

    public void setLista(List<Comentario> nuevaLista) {
        this.lista = nuevaLista;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_comentario, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Comentario c = lista.get(position);

        holder.tvAutor.setText(c.getNombre());
        holder.tvContenido.setText(c.getTexto());


        if (c.getTimestamp() != null) {
            long now = System.currentTimeMillis();

            CharSequence prettyTime = DateUtils.getRelativeTimeSpanString(
                    c.getTimestamp().getTime(),
                    now,
                    DateUtils.MINUTE_IN_MILLIS);
            holder.tvFecha.setText(prettyTime);
        } else {
            holder.tvFecha.setText("Ahora mismo");
        }


        if (c.getIdAutor() != null && c.getIdAutor().equals(miId)) {
            holder.itemView.setOnLongClickListener(v -> {
                if (listener != null) listener.onLongClick(c);
                return true;
            });
        } else {
            holder.itemView.setOnLongClickListener(null);
        }
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAutor, tvContenido, tvFecha;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAutor = itemView.findViewById(R.id.tvAutor);
            tvContenido = itemView.findViewById(R.id.tvContenido);
            tvFecha = itemView.findViewById(R.id.tvFecha);
        }
    }
}