package es.iesagora.ejercicio6;

import android.app.Application;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.List;

import es.iesagora.ejercicio6.model.Comentario;

public class ComentsViewModel extends AndroidViewModel {
    private final CommentsRepository Comentrepository;
    private final MutableLiveData<Resource<List<Comentario>>> comentariosLiveData = new MutableLiveData<>();
    private String currentMediaId;

    public ComentsViewModel(@NonNull Application application) {
        super(application);
        this.Comentrepository = new CommentsRepository();
    }

    public void cargarComentarios(String mediaId) {
        this.currentMediaId = mediaId;
        Comentrepository.escucharComentarios(mediaId, comentariosLiveData);
    }

    public LiveData<Resource<List<Comentario>>> getComentarios() {
        return comentariosLiveData;
    }

    public void agregarComentario(String contenido) {
        if (currentMediaId == null) return;
        if (TextUtils.isEmpty(contenido)) return;

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String nombreUsuario = user.getDisplayName();

            if (TextUtils.isEmpty(nombreUsuario)) {
                if (user.getEmail() != null) {
                    nombreUsuario = user.getEmail().split("@")[0];
                } else {
                    nombreUsuario = "Anónimo";
                }
            }


            Comentario nuevoComentario = new Comentario(
                    nombreUsuario,
                    contenido,
                    user.getUid()
            );

            Comentrepository.enviarComentario(currentMediaId, nuevoComentario);
        }
    }
    public void eliminarComentario(String comentarioId) {
        if (currentMediaId != null) {
            Comentrepository.eliminarComentario(currentMediaId, comentarioId);
        }
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        Comentrepository.stopListening();
    }
}