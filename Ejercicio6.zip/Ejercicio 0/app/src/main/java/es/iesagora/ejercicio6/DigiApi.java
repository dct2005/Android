package es.iesagora.ejercicio6;

import es.iesagora.ejercicio6.model.Example;
import es.iesagora.ejercicio6.model.Example2;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface DigiApi {


    @GET("movie/popular")
    Call<Example> getPeliculas(@Query("page") int page);

    @GET("tv/popular")
    Call<Example2> getPeliculas2(@Query("page") int page);

    @GET("search/movie")
    Call<Example> buscarPeliculaPorNombre(@Query("query") String nombre);

    @GET("search/tv")
    Call<Example2> buscarSeriePorNombre(@Query("query") String nombre);




    @GET("movie/{movie_id}")
    Call<Result> getDetallesPelicula(@Path("movie_id") String id);

    @GET("tv/{tv_id}")
    Call<Result2> getDetallesSerie(@Path("tv_id") String id);
}