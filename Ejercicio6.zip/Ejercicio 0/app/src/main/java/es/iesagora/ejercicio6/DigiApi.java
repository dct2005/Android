package es.iesagora.ejercicio6;

import es.iesagora.ejercicio6.model.Example;
import es.iesagora.ejercicio6.model.Example2;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface DigiApi {
    // CORRECCIÓN: Quitamos "/name". La ruta correcta es digimon/{name}
    // URL Final: https://digi-api.com/api/v1/digimon/agumon  https://api.themoviedb.org/3/movie/popular


    @GET("movie/popular")
    Call<Example> getPeliculas(
            @Query("page") int offset
    );
    @GET("tv/popular")
    Call<Example2> getPeliculas2(
            @Query("page") int offset
    );
    @GET("movie/{movie_id}")
    Call<Result> getPokemonByName(@Path("movie_id") String movie_id);
    @GET("tv/{series_id}")
    Call<Result2> getPokemonByName2(@Path("series_id") String series_id);
}