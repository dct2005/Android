package es.iesagora.ejercicio6;

import android.app.AlertDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayoutMediator;

import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.databinding.FragmentBuscarBinding;


public class InicioFragment extends Fragment {

    private FragmentBuscarBinding binding;
    private CatalogoViewModel viewModel;

    private NavController navController;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentBuscarBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);
        navController = Navigation.findNavController(view);
        establecerAdaptadorViewPager();

       vincularTabLayoutConViewPager();

observarnombre();
observarPendientesYSaludar();
    }

    private void observarnombre() {
        viewModel.getNombre().observe(getViewLifecycleOwner(), esPrimerIngreso -> {
            if (esPrimerIngreso.isEmpty()) {
                mostrarDialogo1();
            }
        });
    }
    private void establecerAdaptadorViewPager() {
        binding.viewPager.setAdapter(new FragmentStateAdapter(this) {
            @NonNull
            @Override
            public Fragment createFragment(int position) {

                switch (position) {
                    default:
                    case 0: return new SeriesFragment();
                    case 1: return new PeliculaFragment();
                }
            }

            @Override
            public int getItemCount() {

                return 2;
            }
        });
    }

    private void mostrarDialogo1() {
        String nombre = viewModel.getNombre().getValue();
        if (nombre == null){
        new AlertDialog.Builder(requireContext())
                .setTitle("¡Bienvenido!")
                .setMessage("“Hola! Para personalizar tu experiencia, puedes configurar tu nombre en los ajustes.\n" +
                        "¿Quieres hacerlo ahora?”")
                .setCancelable(false)
                .setPositiveButton("Continuar", (dialog, which) -> {
                    viewModel.actualizarPrimerIngreso();
                    dialog.dismiss();
                })
                .show();
        }
    }

    private void observarPendientesYSaludar() {
        // Observamos la base de datos
        viewModel.ObtenerPeliculas().observe(getViewLifecycleOwner(), lista -> {
            String nombre = viewModel.getNombre().getValue();

            // Verificamos condiciones: hay nombre, hay lista y no se ha mostrado aún este diálogo
            if (nombre != null && !nombre.isEmpty() && lista != null && !lista.isEmpty() && !viewModel.isDialogoMostrado()) {

                PeliculaySerie aleatoria = viewModel.obtenerPendienteAleatoria(lista);

                if (aleatoria != null) {
                    mostrarDialogoBienvenidaPersonalizado(nombre, aleatoria);
                    viewModel.setDialogoMostrado(true); // Evitamos que salga todo el tiempo
                }
            }
        });
    }

    private void mostrarDialogoBienvenidaPersonalizado(String nombre, PeliculaySerie item) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Sugerencia")
                .setMessage("Hola, " + nombre + ". ¿Has visto ya tu película o serie pendiente " + item.getTitulo() + "?")
                .setCancelable(true)
                .setPositiveButton("Añadir Seguimiento", (dialog, which) -> {
                    // Pasamos los datos al ViewModel para que la pantalla de "Añadir" los lea
                    viewModel.seleccionarAnimalDesdeFavoritos(item);

                    // Navegamos (Asegúrate de que el ID de la acción sea el correcto en tu nav_graph)
                    navController.navigate(R.id.action_InicioFragment_to_pendientesFragment);
                })
                .setNegativeButton("Aún no", (dialog, which) -> dialog.dismiss())
                .show();
    }


    private void vincularTabLayoutConViewPager() {
        new TabLayoutMediator(binding.tabLayout, binding.viewPager,
                (tab, position) -> {
                    switch (position) {
                        case 0:
                            tab.setText("Series");
                            break;
                        case 1:
                            tab.setText("Peliculas");
                            break;
                    }
                }).attach();
    }
    }






