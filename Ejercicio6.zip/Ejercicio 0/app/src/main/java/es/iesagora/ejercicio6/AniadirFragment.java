package es.iesagora.ejercicio6;

import static android.app.Activity.RESULT_OK;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import com.bumptech.glide.Glide;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import es.iesagora.ejercicio6.data.Seguimiento;
import es.iesagora.ejercicio6.databinding.FragmentAniadirBinding;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;

public class AniadirFragment extends Fragment {
    private FragmentAniadirBinding binding;
    private byte[] fotoBlob;
    private CatalogoViewModel catalogoViewModel;

    private final ActivityResultLauncher<Intent> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri imageUri = result.getData().getData();
                    fotoBlob = ImageUtils.uriToBlob(requireContext().getContentResolver(), imageUri);
                    binding.imgPrevisualizacion.setImageBitmap(ImageUtils.blobToBitmap(fotoBlob));
                    binding.imgPrevisualizacion.setVisibility(View.VISIBLE);
                }
            }
    );

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return (binding = FragmentAniadirBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        catalogoViewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);
        observarResultadosBusqueda();

        binding.btnBuscarTMDB.setOnClickListener(v -> {
            String query = binding.editTituloBusqueda.getText().toString().trim();
            if (query.isEmpty()) return;
            catalogoViewModel.reset();
            if (binding.toggleGroupTipo.getCheckedButtonId() == R.id.btnTipoPelicula) {
                catalogoViewModel.buscar(query);
            } else {
                catalogoViewModel.buscar2(query);
            }
        });

        binding.btnGuardarSeguimiento.setOnClickListener(v -> guardarConSupabase());

        binding.btnSubirImagen.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            imagePickerLauncher.launch(intent);
        });

        binding.editFecha.setOnClickListener(v -> {
            java.util.Calendar c = java.util.Calendar.getInstance();
            new android.app.DatePickerDialog(requireContext(), (view1, y, m, d) -> {
                String fecha = String.format("%04d-%02d-%02d", y, (m + 1), d);
                binding.editFecha.setText(fecha);
            }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show();
        });
    }

    private void guardarConSupabase() {
        if (binding.spinnerResultados.getSelectedItem() == null) return;

        String nombre = binding.spinnerResultados.getSelectedItem().toString();
        String fecha = binding.editFecha.getText().toString();
        if (fecha.isEmpty()) return;

        int checkedId = binding.toggleGroupTipo.getCheckedButtonId();
        String tipo = (checkedId == R.id.btnTipoPelicula) ? "Película" : "Serie";
        float puntos = binding.ratingPuntuacion.getRating();

        String urlApi = "";
        if (tipo.equals("Película") && catalogoViewModel.Peliculas.getValue() != null) {
            for (Result p : catalogoViewModel.Peliculas.getValue().data) {
                if (p.getTitle().equals(nombre)) {
                    urlApi = "https://image.tmdb.org/t/p/w500" + p.getPosterPath();
                    break;
                }
            }
        } else if (catalogoViewModel.Series.getValue() != null) {
            for (Result2 s : catalogoViewModel.Series.getValue().data) {
                if (s.getName().equals(nombre)) {
                    urlApi = "https://image.tmdb.org/t/p/w500" + s.getPosterPath();
                    break;
                }
            }
        }

        final String finalUrl = urlApi;
        android.content.Context ctx = requireContext().getApplicationContext();

        new Thread(() -> {
            try {
                Bitmap bitmap = null;
                if (!finalUrl.isEmpty()) {
                    bitmap = Glide.with(ctx).asBitmap().load(finalUrl).submit().get();
                } else if (fotoBlob != null) {
                    bitmap = ImageUtils.blobToBitmap(fotoBlob);
                }

                if (bitmap != null) {
                    Bitmap resized = redimensionar(bitmap, 600);
                    ByteArrayOutputStream os = new ByteArrayOutputStream();
                    resized.compress(Bitmap.CompressFormat.JPEG, 50, os);
                    byte[] data = os.toByteArray();

                    String fileName = System.currentTimeMillis() + ".jpg";
                    SupabaseStorage.subirImagen(data, fileName, new SupabaseStorage.UploadCallback() {
                        @Override
                        public void onSuccess(String imageUrl) {
                            Seguimiento s = new Seguimiento(tipo, nombre, fecha, puntos, imageUrl);
                            s.setId((int) System.currentTimeMillis());
                            catalogoViewModel.insertarSerie(s);
                            requireActivity().runOnUiThread(() -> {
                                Toast.makeText(ctx, "Guardado", Toast.LENGTH_SHORT).show();
                                Navigation.findNavController(binding.getRoot()).popBackStack();
                            });
                        }
                        @Override
                        public void onError(String msg) {
                            requireActivity().runOnUiThread(() -> Toast.makeText(ctx, "Error Supabase: " + msg, Toast.LENGTH_SHORT).show());
                        }
                    });
                }
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> Toast.makeText(ctx, "Error procesando imagen", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private Bitmap redimensionar(Bitmap b, int max) {
        int w = b.getWidth();
        int h = b.getHeight();
        float ratio = (float) w / (float) h;
        if (ratio > 1) { w = max; h = (int) (w / ratio); }
        else { h = max; w = (int) (h * ratio); }
        return Bitmap.createScaledBitmap(b, w, h, true);
    }

    private void observarResultadosBusqueda() {
        catalogoViewModel.Peliculas.observe(getViewLifecycleOwner(), res -> {
            if (res != null && res.data != null) {
                List<String> t = new ArrayList<>();
                for (Result p : res.data) t.add(p.getTitle());
                actualizarSpinner(t);
            }
        });
        catalogoViewModel.Series.observe(getViewLifecycleOwner(), res -> {
            if (res != null && res.data != null) {
                List<String> t = new ArrayList<>();
                for (Result2 s : res.data) t.add(s.getName());
                actualizarSpinner(t);
            }
        });
    }

    private void actualizarSpinner(List<String> n) {
        ArrayAdapter<String> a = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, n);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerResultados.setAdapter(a);
    }
}