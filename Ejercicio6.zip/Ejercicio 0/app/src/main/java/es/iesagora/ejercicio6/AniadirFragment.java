package es.iesagora.ejercicio6;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import es.iesagora.ejercicio6.data.Seguimiento;
import es.iesagora.ejercicio6.databinding.FragmentAniadirBinding;


public class AniadirFragment extends Fragment {
    private FragmentAniadirBinding binding;
    private CatalogoViewModel catalogoViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return (binding = FragmentAniadirBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        catalogoViewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);
        binding.btnGuardarSeguimiento.setOnClickListener(v -> anadirAnimal());
    }

    private void anadirAnimal() {
        String nombre = binding.editTituloBusqueda.getText().toString();



       // Seguimiento nuevoAnimal = new Seguimiento(nombre);
        //catalogoViewModel.insertarSerie(nuevoAnimal);

        Toast.makeText(requireActivity(), "Animal añadido con éxito", Toast.LENGTH_SHORT);

        // Volvemos al fragment anterior
        requireActivity().getSupportFragmentManager().popBackStack();
    }
}