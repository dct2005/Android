package es.iesagora.ejercicio6;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.ejercicio6.data.Seguimiento;
import es.iesagora.ejercicio6.databinding.FragmentAniadirBinding;
import es.iesagora.ejercicio6.model.Result;


public class AniadirFragment extends Fragment {
    private FragmentAniadirBinding binding;

    private byte[] fotoBlob;
    private CatalogoViewModel catalogoViewModel;


    private final ActivityResultLauncher<Intent> imagePickerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri imageUri = result.getData().getData();
                    fotoBlob = ImageUtils.uriToBlob(requireContext().getContentResolver(), imageUri);
                    binding.imgPrevisualizacion.setImageBitmap(ImageUtils.blobToBitmap(fotoBlob));
                    binding.imgPrevisualizacion.setVisibility(View.VISIBLE);
                }
            }
    );
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return (binding = FragmentAniadirBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        catalogoViewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);
        observarResultadosBusqueda();
        binding.btnBuscarTMDB.setOnClickListener(v -> {
            String query = binding.editTituloBusqueda.getText().toString().trim();
            if (query.isEmpty()) {
                Toast.makeText(getContext(), "Introduce un título para buscar", Toast.LENGTH_SHORT).show();
                return;
            }

         catalogoViewModel.reset();

            int checkedId = binding.toggleGroupTipo.getCheckedButtonId();
            if (checkedId == R.id.btnTipoPelicula) {
                catalogoViewModel.buscar(query);
            } else {
                catalogoViewModel.buscar2(query);
            }
        });





        binding.btnGuardarSeguimiento.setOnClickListener(v -> anadirAnimal());




        binding.btnSubirImagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                imagePickerLauncher.launch(intent);
            }
        });

        binding.editFecha.setOnClickListener(v -> {
            java.util.Calendar calendar = java.util.Calendar.getInstance();
            int year = calendar.get(java.util.Calendar.YEAR);
            int month = calendar.get(java.util.Calendar.MONTH);
            int day = calendar.get(java.util.Calendar.DAY_OF_MONTH);

            android.app.DatePickerDialog datePicker = new android.app.DatePickerDialog(requireContext(),
                    (view1, selectedYear, selectedMonth, selectedDay) -> {
                        String fecha = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        binding.editFecha.setText(fecha);
                    }, year, month, day);
            datePicker.show();
        });

    }



    private void anadirAnimal() {
        if (binding.spinnerResultados.getSelectedItem() == null) {
            Toast.makeText(getContext(), "Primero busca y selecciona un título", Toast.LENGTH_SHORT).show();
            return;
        }
        String nombre = binding.spinnerResultados.getSelectedItem().toString();

        String fecha = binding.editFecha.getText().toString();
        if (fecha.isEmpty()) {
            Toast.makeText(getContext(), "Selecciona una fecha de visualización", Toast.LENGTH_SHORT).show();
            return;
        }

        String tipoSeleccionado = "";
        int checkedId = binding.toggleGroupTipo.getCheckedButtonId();
        if (checkedId == R.id.btnTipoPelicula) {
            tipoSeleccionado = "Película";
        } else {
            tipoSeleccionado = "Serie";
        }

        float puntuacion = binding.ratingPuntuacion.getRating();


        String urlImagenApi = "";
        if (tipoSeleccionado.equals("Película") && catalogoViewModel.Peliculas.getValue() != null) {
            for (Result p : catalogoViewModel.Peliculas.getValue().data) {
                if (p.getTitle().equals(nombre)) {
                    urlImagenApi = "https://image.tmdb.org/t/p/w500" + p.getPosterPath();
                    break;
                }
            }
        } else if (catalogoViewModel.Series.getValue() != null) {
            for (es.iesagora.ejercicio6.model.Result2 s : catalogoViewModel.Series.getValue().data) {
                if (s.getName().equals(nombre)) {
                    urlImagenApi = "https://image.tmdb.org/t/p/w500" + s.getPosterPath();
                    break;
                }
            }
        }

        final String finalUrl = urlImagenApi;
        final String finalTipo = tipoSeleccionado;


        new Thread(() -> {
            try {
                byte[] imagenAGuardar;

                if (!finalUrl.isEmpty()) {
                    android.graphics.Bitmap bitmap = Glide.with(requireContext())
                            .asBitmap()
                            .load(finalUrl)
                            .submit()
                            .get();

                    java.io.ByteArrayOutputStream stream = new java.io.ByteArrayOutputStream();
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, stream);
                    imagenAGuardar = stream.toByteArray();
                } else {

                    imagenAGuardar = fotoBlob;
                }


                Seguimiento nuevoSeguimiento = new Seguimiento(finalTipo, nombre, fecha, puntuacion, imagenAGuardar);
                catalogoViewModel.insertarSerie(nuevoSeguimiento);


                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(requireContext(), "Seguimiento guardado", Toast.LENGTH_SHORT).show();
                    androidx.navigation.Navigation.findNavController(requireView()).popBackStack();
                });

            } catch (Exception e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() ->
                        Toast.makeText(requireContext(), "Error al guardar imagen", Toast.LENGTH_SHORT).show()
                );
            }
        }).start();
    }

    private void observarResultadosBusqueda() {

        catalogoViewModel.Peliculas.observe(getViewLifecycleOwner(), resource -> {
            if (resource != null && resource.status == Resource.Status.SUCCESS && resource.data != null) {
                List<String> titulos = new ArrayList<>();
                for (Result peli : resource.data) {
                    titulos.add(peli.getTitle());
                }
                actualizarSpinner(titulos);
            }
        });


        catalogoViewModel.Series.observe(getViewLifecycleOwner(), resource -> {
            if (resource != null && resource.status == Resource.Status.SUCCESS && resource.data != null) {
                List<String> titulos = new ArrayList<>();
                for (es.iesagora.ejercicio6.model.Result2 serie : resource.data) {
                    titulos.add(serie.getName()); // Result2 usa getName() normalmente
                }
                actualizarSpinner(titulos);
            }
        });
    }


    private void actualizarSpinner(List<String> nombres) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_item, nombres);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerResultados.setAdapter(adapter);
    }
}