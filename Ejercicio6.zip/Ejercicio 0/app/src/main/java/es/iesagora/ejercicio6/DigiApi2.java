package es.iesagora.ejercicio6;

import es.iesagora.ejercicio6.model.Example;
import es.iesagora.ejercicio6.model.Result;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface DigiApi2 {
    // CORRECCIÓN: Quitamos "/name". La ruta correcta es digimon/{name}
    // URL Final: https://digi-api.com/api/v1/digimon/agumon  https://api.themoviedb.org/3/movie/popular


    @GET("tv/popular")
    Call<Example> getPeliculas2(
            @Query("page") int offset
    );

    @GET("tv/{series_id}")
    Call<Result> getPokemonByName2(@Path("series_id") String series_id);
}