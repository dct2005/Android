package es.iesagora.ejercicio6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.databinding.ViewholderCatalogoBinding;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;

public class CatalogoAdapter extends RecyclerView.Adapter<CatalogoAdapter.CatalogoViewHolder> {
    List<es.iesagora.ejercicio6.data.Seguimiento> listaSeguimiento;
    List<Result> pokemonList;
    List<Result2> pokemonList2;
    private final LayoutInflater inflater;
    private CatalogoViewModel viewModel;
    private Context context;

    List<PeliculaySerie> listaAnimales;
    public CatalogoAdapter(Context context, CatalogoViewModel viewModel) {
        this.inflater = LayoutInflater.from(context);
        this.pokemonList = new ArrayList<>();
        this.viewModel = viewModel;
        this.pokemonList2 = new ArrayList<>();
        this.context = context;
        this.listaAnimales = new ArrayList<>();
        this.listaSeguimiento = new ArrayList<>();
    }

    @NonNull
    @Override
    public CatalogoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.viewholder_catalogo, parent, false);
        return new CatalogoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CatalogoViewHolder holder, int position) {




        if (!listaSeguimiento.isEmpty()) {
            es.iesagora.ejercicio6.data.Seguimiento item = listaSeguimiento.get(position);

            Glide.with(context).clear(holder.binding.imgPokemonItem);
            holder.binding.imgPokemonItem.setImageDrawable(null);
            holder.binding.imgPokemonItem.setBackground(null);
            holder.binding.imgPokemonItem.setColorFilter(null);


            holder.binding.tvPokemonNameItem.setText(item.getTitulo());
            holder.binding.tvPokemonNumber.setText("Visto el: " + item.getFecha());


            holder.binding.btnFavorito.setVisibility(View.GONE);


            if (item.getFoto() != null) {
                android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(
                        item.getFoto(), 0, item.getFoto().length
                );
                holder.binding.imgPokemonItem.setImageBitmap(bitmap);


                holder.binding.imgPokemonItem.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
                holder.binding.imgPokemonItem.setBackgroundColor(android.graphics.Color.TRANSPARENT);
            } else {
                holder.binding.imgPokemonItem.setImageResource(android.R.drawable.ic_menu_gallery);
            }


            holder.itemView.setOnClickListener(v -> {
                Toast.makeText(context, "Puntuación: " + item.getPuntuacion(), Toast.LENGTH_SHORT).show();
            });

            holder.itemView.setOnClickListener(v -> {

                viewModel.seleccionarSeguimiento(item);

               Navigation.findNavController(v).navigate(R.id.action_seguimientoFragment_to_detalleSeguimientoFragment);
            });
        }

        else if (!listaAnimales.isEmpty()) {
            PeliculaySerie item = listaAnimales.get(position);
            configurarUI(holder, item.getTitulo(), item.getDescripcion(), item.getURL());


            holder.itemView.setOnClickListener(v -> {
                viewModel.seleccionarAnimalDesdeFavoritos(item);


                Navigation.findNavController(v).navigate(R.id.toInformacion);
            });
        }

        else if (!pokemonList.isEmpty()) {
            Result pelicula = pokemonList.get(position);
            configurarUI(holder, pelicula.getTitle(), pelicula.getOverview(), pelicula.getPosterPath());

            holder.binding.btnFavorito.setOnClickListener(v ->
                    viewModel.insertarPelicula(new PeliculaySerie(pelicula.getPosterPath(), pelicula.getId(), pelicula.getTitle(), pelicula.getOverview()))
            );
            holder.itemView.setOnClickListener(v -> {
                viewModel.seleccionarAnimal(pelicula);
                Navigation.findNavController(v).navigate(R.id.toInformacion);
            });
        }

        else if (!pokemonList2.isEmpty()) {
            Result2 serie = pokemonList2.get(position);
            configurarUI(holder, serie.getName(), serie.getOverview(), serie.getPosterPath());

            holder.binding.btnFavorito.setOnClickListener(v ->
                    viewModel.insertarPelicula(new PeliculaySerie(serie.getPosterPath(), serie.getId(), serie.getName(), serie.getOverview()))
            );
            holder.itemView.setOnClickListener(v -> {
                viewModel.seleccionarAnimal2(serie);
                Navigation.findNavController(v).navigate(R.id.toInformacion);
            });
        }

    }


    private void configurarUI(CatalogoViewHolder holder, String titulo, String desc, String url) {
        holder.binding.tvPokemonNameItem.setText(titulo);
        holder.binding.tvPokemonNumber.setText(desc);
        Glide.with(context)
                .load("https://image.tmdb.org/t/p/w500" + url)
                .placeholder(android.R.drawable.ic_menu_upload)
                .into(holder.binding.imgPokemonItem);
    }




    private void establecerIconoFavorito( CatalogoViewHolder holder) {

            holder.binding.btnFavorito.setImageResource(android.R.drawable.star_on);


    }

    public void establecerListaSeguimiento(List<es.iesagora.ejercicio6.data.Seguimiento> lista) {
        this.listaSeguimiento = lista;

        this.listaAnimales.clear();
        this.pokemonList.clear();
        this.pokemonList2.clear();
        notifyDataSetChanged();
    }



        public void establecerLista(List<PeliculaySerie> listaAnimales){
            this.listaAnimales = listaAnimales;
            notifyDataSetChanged();
        }




    @Override
    public int getItemCount() {
        if (listaSeguimiento != null && !listaSeguimiento.isEmpty()) return listaSeguimiento.size();
        if (listaAnimales != null && !listaAnimales.isEmpty()) return listaAnimales.size();
        if (pokemonList != null && !pokemonList.isEmpty()) return pokemonList.size();
        if (pokemonList2 != null && !pokemonList2.isEmpty()) return pokemonList2.size();
        return 0;
    }



    public void addPokemonList(List<Result> nuevos) {

        if (!pokemonList2.isEmpty()) pokemonList2.clear();

        int inicio = pokemonList.size();
        this.pokemonList.addAll(nuevos);
        notifyItemRangeInserted(inicio, nuevos.size());
    }

    public void addPokemonList2(List<Result2> nuevos) {

        if (!pokemonList.isEmpty()) pokemonList.clear();

        int inicio = pokemonList2.size();
        this.pokemonList2.addAll(nuevos);
        notifyItemRangeInserted(inicio, nuevos.size());
    }

    public class CatalogoViewHolder extends RecyclerView.ViewHolder {
        public final ViewholderCatalogoBinding binding;

        public CatalogoViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ViewholderCatalogoBinding.bind(itemView);
        }
    }
}