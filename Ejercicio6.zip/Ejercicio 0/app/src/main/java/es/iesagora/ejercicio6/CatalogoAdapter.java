package es.iesagora.ejercicio6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.databinding.ViewholderCatalogoBinding;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;

public class CatalogoAdapter extends RecyclerView.Adapter<CatalogoAdapter.CatalogoViewHolder> {
    List<es.iesagora.ejercicio6.data.Seguimiento> listaSeguimiento;
    List<Result> Peliculaslist;
    List<Result2> SeriesList;
    private final LayoutInflater inflater;
    private CatalogoViewModel viewModel;
    private Context context;

    List<PeliculaySerie> listaAnimales;
    public CatalogoAdapter(Context context, CatalogoViewModel viewModel) {
        this.inflater = LayoutInflater.from(context);
        this.Peliculaslist = new ArrayList<>();
        this.viewModel = viewModel;
        this.SeriesList = new ArrayList<>();
        this.context = context;
        this.listaAnimales = new ArrayList<>();
        this.listaSeguimiento = new ArrayList<>();
    }

    @NonNull
    @Override
    public CatalogoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.viewholder_catalogo, parent, false);
        return new CatalogoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CatalogoViewHolder holder, int position) {




        if (!listaSeguimiento.isEmpty()) {
            es.iesagora.ejercicio6.data.Seguimiento item = listaSeguimiento.get(position);


            holder.binding.imgSeguimientoItem.setImageDrawable(null);

            holder.binding.tvSeguimientoNameItem.setText(item.getTitulo());
            holder.binding.tvSeguimientoNumber.setText("Puntos: " + item.getPuntuacion());
            holder.binding.btnFavorito.setVisibility(View.GONE);


            if (item.getFoto() != null && !item.getFoto().isEmpty()) {
                String urlLimpia = item.getFoto().trim();

                Glide.with(context)
                        .load(urlLimpia)
                        .placeholder(android.R.color.darker_gray)
                        .error(android.R.color.holo_red_dark)
                        .centerCrop()
                        .into(holder.binding.imgSeguimientoItem);

                android.util.Log.d("SUPABASE_CHECK", "Intentando cargar: " + urlLimpia);
            } else {
                holder.binding.imgSeguimientoItem.setImageResource(android.R.drawable.ic_menu_gallery);
            }


            holder.itemView.setOnClickListener(v -> {
                viewModel.seleccionarSeguimiento(item);
                Navigation.findNavController(v).navigate(R.id.action_seguimientoFragment_to_detalleSeguimientoFragment);
            });
        }

        else if (!listaAnimales.isEmpty()) {
            PeliculaySerie item = listaAnimales.get(position);
            configurarUI(holder, item.getTitulo(), item.getDescripcion(), item.getURL());


            holder.itemView.setOnClickListener(v -> {
                viewModel.seleccionarAnimalDesdeFavoritos(item);


                Navigation.findNavController(v).navigate(R.id.toInformacion);
            });
        }

        else if (!Peliculaslist.isEmpty()) {
            Result pelicula = Peliculaslist.get(position);
            configurarUI(holder, pelicula.getTitle(), pelicula.getOverview(), pelicula.getPosterPath());

            holder.binding.btnFavorito.setOnClickListener(v ->
                    viewModel.insertarPelicula(new PeliculaySerie(pelicula.getPosterPath(), pelicula.getId(), pelicula.getTitle(), pelicula.getOverview()))
            );


            holder.itemView.setOnClickListener(v -> {

                int edadUsuario = viewModel.getEdadUsuarioActual();


                if (pelicula.getAdult()!= null && pelicula.getAdult() && edadUsuario < 18){

                    android.widget.Toast.makeText(context,
                            "🚫 Acceso denegado: Contenido para mayores de 18 años",
                            android.widget.Toast.LENGTH_LONG).show();
                } else {

                    viewModel.seleccionarAnimal(pelicula);
                    androidx.navigation.Navigation.findNavController(v).navigate(R.id.toInformacion);
                }
            });
        }
        else if (!SeriesList.isEmpty()) {
            Result2 serie = SeriesList.get(position);
            configurarUI(holder, serie.getName(), serie.getOverview(), serie.getPosterPath());

            holder.binding.btnFavorito.setOnClickListener(v ->
                    viewModel.insertarPelicula(new PeliculaySerie(serie.getPosterPath(), serie.getId(), serie.getName(), serie.getOverview()))
            );

            holder.itemView.setOnClickListener(v -> {

                int edadUsuario = viewModel.getEdadUsuarioActual();


                if (serie.getAdult()!= null && serie.getAdult() && edadUsuario < 18) {
                    android.widget.Toast.makeText(context,
                            "🚫 Acceso denegado: Serie para mayores de 18 años",
                            android.widget.Toast.LENGTH_LONG).show();
                } else {
                    viewModel.seleccionarAnimal2(serie);
                    Navigation.findNavController(v).navigate(R.id.toInformacion);
                }
            });
        }

    }


    private void configurarUI(CatalogoViewHolder holder, String titulo, String desc, String url) {
        holder.binding.tvSeguimientoNameItem.setText(titulo);
        holder.binding.tvSeguimientoNumber.setText(desc);
        Glide.with(context)
                .load("https://image.tmdb.org/t/p/w500" + url)
                .placeholder(android.R.drawable.ic_menu_upload)
                .into(holder.binding.imgSeguimientoItem);
    }






    private void establecerIconoFavorito( CatalogoViewHolder holder) {

            holder.binding.btnFavorito.setImageResource(android.R.drawable.star_on);


    }

    public void establecerListaSeguimiento(List<es.iesagora.ejercicio6.data.Seguimiento> lista) {

        this.listaSeguimiento = new ArrayList<>(lista);


        this.Peliculaslist.clear();
        this.SeriesList.clear();
        this.listaAnimales.clear();


        notifyDataSetChanged();
    }



        public void establecerLista(List<PeliculaySerie> listaAnimales){
            this.listaAnimales = listaAnimales;
            notifyDataSetChanged();
        }




    @Override
    public int getItemCount() {
        if (listaSeguimiento != null && !listaSeguimiento.isEmpty()) return listaSeguimiento.size();
        if (listaAnimales != null && !listaAnimales.isEmpty()) return listaAnimales.size();
        if (Peliculaslist != null && !Peliculaslist.isEmpty()) return Peliculaslist.size();
        if (SeriesList != null && !SeriesList.isEmpty()) return SeriesList.size();
        return 0;
    }



    public void addPeliculaList(List<Result> nuevos) {

        if (!SeriesList.isEmpty()) SeriesList.clear();

        int inicio = Peliculaslist.size();
        this.Peliculaslist.addAll(nuevos);
        notifyItemRangeInserted(inicio, nuevos.size());
    }

    public void addSerieList2(List<Result2> nuevos) {

        if (!Peliculaslist.isEmpty()) Peliculaslist.clear();

        int inicio = SeriesList.size();
        this.SeriesList.addAll(nuevos);
        notifyItemRangeInserted(inicio, nuevos.size());
    }

    public class CatalogoViewHolder extends RecyclerView.ViewHolder {
        public final ViewholderCatalogoBinding binding;

        public CatalogoViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ViewholderCatalogoBinding.bind(itemView);
        }
    }
}