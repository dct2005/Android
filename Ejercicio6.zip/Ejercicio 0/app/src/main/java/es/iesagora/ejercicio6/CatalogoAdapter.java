package es.iesagora.ejercicio6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.databinding.ViewholderCatalogoBinding;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;

public class CatalogoAdapter extends RecyclerView.Adapter<CatalogoAdapter.CatalogoViewHolder> {

    List<Result> pokemonList;
    List<Result2> pokemonList2;
    private final LayoutInflater inflater;
    private CatalogoViewModel viewModel;
    private Context context;

    List<PeliculaySerie> listaAnimales;
    public CatalogoAdapter(Context context, CatalogoViewModel viewModel) {
        this.inflater = LayoutInflater.from(context);
        this.pokemonList = new ArrayList<>();
        this.viewModel = viewModel;
        this.pokemonList2 = new ArrayList<>();
        this.context = context;
        this.listaAnimales = new ArrayList<>();
    }

    @NonNull
    @Override
    public CatalogoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.viewholder_catalogo, parent, false);
        return new CatalogoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CatalogoViewHolder holder, int position) {
        // CASO 1: Estamos en PENDIENTES (Datos de Room)
        if (!listaAnimales.isEmpty()) {
            PeliculaySerie item = listaAnimales.get(position);
            configurarUI(holder, item.getTitulo(), item.getDescripcion(), item.getURL());
            // Aquí puedes ocultar el botón de favorito o cambiar su icono

            holder.itemView.setOnClickListener(v -> {
                viewModel.PeliculaySerie(item);
                Navigation.findNavController(v).navigate(R.id.action_buscarFragment_to_informacionFragment);
            });
        }
        // CASO 2: Estamos en EXPLORAR PELÍCULAS (API)
        else if (!pokemonList.isEmpty()) {
            Result pelicula = pokemonList.get(position);
            configurarUI(holder, pelicula.getTitle(), pelicula.getOverview(), pelicula.getPosterPath());

            holder.binding.btnFavorito.setOnClickListener(v ->
                    viewModel.insertarPelicula(new PeliculaySerie(pelicula.getPosterPath(), pelicula.getId(), pelicula.getTitle(), pelicula.getOverview()))
            );
            holder.itemView.setOnClickListener(v -> {
                viewModel.seleccionarAnimal(pelicula);
                Navigation.findNavController(v).navigate(R.id.action_buscarFragment_to_informacionFragment);
            });
        }
        // CASO 3: Estamos en EXPLORAR SERIES (API)
        else if (!pokemonList2.isEmpty()) {
            Result2 serie = pokemonList2.get(position);
            configurarUI(holder, serie.getName(), serie.getOverview(), serie.getPosterPath());

            holder.binding.btnFavorito.setOnClickListener(v ->
                    viewModel.insertarPelicula(new PeliculaySerie(serie.getPosterPath(), serie.getId(), serie.getName(), serie.getOverview()))
            );
            holder.itemView.setOnClickListener(v -> {
                viewModel.seleccionarAnimal2(serie);
                Navigation.findNavController(v).navigate(R.id.action_buscarFragment_to_informacionFragment);
            });
        }
    }

    // Método auxiliar para no repetir código de Glide y Textos
    private void configurarUI(CatalogoViewHolder holder, String titulo, String desc, String url) {
        holder.binding.tvPokemonNameItem.setText(titulo);
        holder.binding.tvPokemonNumber.setText(desc);
        Glide.with(context)
                .load("https://image.tmdb.org/t/p/w500" + url)
                .placeholder(android.R.drawable.ic_menu_upload)
                .into(holder.binding.imgPokemonItem);
    }




    private void establecerIconoFavorito( CatalogoViewHolder holder) {

            holder.binding.btnFavorito.setImageResource(android.R.drawable.star_on);


    }



        public void establecerLista(List<PeliculaySerie> listaAnimales){
            this.listaAnimales = listaAnimales;
            notifyDataSetChanged();
        }




    @Override
    public int getItemCount() {
        if (!listaAnimales.isEmpty()) {
            return listaAnimales.size();
        } else if (!pokemonList.isEmpty()) {
            return pokemonList.size();
        } else if (!pokemonList2.isEmpty()) {
            return pokemonList2.size();
        }
        return 0;
    }

    // --- MÉTODOS PARA AÑADIR DATOS ---

    public void addPokemonList(List<Result> nuevos) {
        // Si añadimos películas, nos aseguramos de limpiar series para evitar conflictos
        if (!pokemonList2.isEmpty()) pokemonList2.clear();

        int inicio = pokemonList.size();
        this.pokemonList.addAll(nuevos);
        notifyItemRangeInserted(inicio, nuevos.size());
    }

    public void addPokemonList2(List<Result2> nuevos) {
        // Si añadimos series, nos aseguramos de limpiar películas
        if (!pokemonList.isEmpty()) pokemonList.clear();

        int inicio = pokemonList2.size();
        this.pokemonList2.addAll(nuevos);
        notifyItemRangeInserted(inicio, nuevos.size());
    }

    public class CatalogoViewHolder extends RecyclerView.ViewHolder {
        public final ViewholderCatalogoBinding binding;

        public CatalogoViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ViewholderCatalogoBinding.bind(itemView);
        }
    }
}