package es.iesagora.ejercicio6;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import com.google.firebase.firestore.Query;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import android.net.Uri;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.data.Seguimiento;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;
import es.iesagora.ejercicio6.model.Usuario;

public class CatalogoViewModel extends AndroidViewModel {

    private RepositoryDatabase repositoryDatabase;

    private final MutableLiveData<List<Seguimiento>> listaSeguimientoFiltrada = new MutableLiveData<>();
    private final APIRepository repository;
    private int edadUsuarioActual = 0;
    private MutableLiveData<Boolean> yaExisteEnLista = new MutableLiveData<>();
    private final PreferencesRepository repository2;
    private final UserRepository repo;

    private boolean dialogoMostrado = false;
    private final MutableLiveData<AuthState> authState = new MutableLiveData<>();
    private MutableLiveData<Boolean> primerIngreso = new MutableLiveData<>();
    private MutableLiveData<String> nombre = new MutableLiveData<>();
    private MutableLiveData<String> idioma = new MutableLiveData<>();
    private MutableLiveData<Boolean> tema = new MutableLiveData<>();

    public MutableLiveData<Result> Peliseleccionada = new MutableLiveData<>();
    public MutableLiveData<Result2> SerieSeleccionada = new MutableLiveData<>();
    public MutableLiveData<PeliculaySerie> PeliculaySerie = new MutableLiveData<>();
    private MutableLiveData<Seguimiento> seguimientoSeleccionado = new MutableLiveData<>();

    public MutableLiveData<Resource<List<Result>>> Peliculas = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Result2>>> Series = new MutableLiveData<>();

    public CatalogoViewModel(@NonNull Application application) {
        super(application);

        repository = new APIRepository();
        repository2 = new PreferencesRepository(application);
        repo = new UserRepository();
        repositoryDatabase = new RepositoryDatabase(application);

        comprobarNOmbre();
        comprobarPrimerIngreso();
    }

    public LiveData<List<PeliculaySerie>> ObtenerPeliculas() {
        return repositoryDatabase.ObtenerPeliculas();
    }

    public void insertarPelicula(PeliculaySerie peliculaySerie) {
        repositoryDatabase.insertar(peliculaySerie);
    }

    public LiveData<List<Seguimiento>> ObtenerSerie() {
        return repositoryDatabase.ObtenerSeries();
    }

    public void insertarSerie(Seguimiento seguimiento) {
        repositoryDatabase.insertarSerie(seguimiento);
    }

    public void filtrarSeguimiento(String titulo, Float min, Float max, String inicio, String fin, String campo, boolean ascendente) {
        Query.Direction dir = ascendente ? Query.Direction.ASCENDING : Query.Direction.DESCENDING;


        LiveData<List<Seguimiento>> fuente = repositoryDatabase.ObtenerSeriesFiltradas(titulo, min, max, inicio, fin, campo, dir);


        fuente.observeForever(new androidx.lifecycle.Observer<List<Seguimiento>>() {
            @Override
            public void onChanged(List<Seguimiento> lista) {
                if (lista != null) {
                    listaSeguimientoFiltrada.postValue(lista);

                    fuente.removeObserver(this);
                }
            }
        });
    }

    public MutableLiveData<AuthState> getAuthState() {
        return authState;
    }

    public FirebaseUser getCurrentUser() {
        return repo.getCurrentUser();
    }
    public LiveData<Boolean> getYaExisteEnLista() {
        return yaExisteEnLista;
    }
    public void actualizarFotoPerfil(Uri nuevaUri) {
        FirebaseUser user = repo.getCurrentUser();
        if (user == null) return;

        authState.setValue(AuthState.loading());
        subirFotoPerfilSupabase(user.getUid(), nuevaUri, new OnImageUploadCallback() {
            @Override
            public void onComplete(String url) {
                FirebaseFirestore.getInstance().collection("users")
                        .document(user.getUid())
                        .update("fotoPerfil", url)
                        .addOnSuccessListener(aVoid -> authState.postValue(AuthState.success(user)))
                        .addOnFailureListener(e -> authState.postValue(AuthState.error(e.getMessage())));
            }

            @Override
            public void onError(String error) {
                authState.postValue(AuthState.error(error));
            }
        });
    }

    public void comprobarExistencia(String id, boolean esPelicula) {
        if (esPelicula) {
            repositoryDatabase.existePelicula(id, existe -> yaExisteEnLista.postValue(existe));
        } else {
            repositoryDatabase.existeSerie(id, existe -> yaExisteEnLista.postValue(existe));
        }
    }
    public LiveData<List<Seguimiento>> getListaSeguimiento() {
        return listaSeguimientoFiltrada;
    }

    public void logout() {
        repo.logout();
    }

    public void login(String email, String password) {
        String error = validate(email, password, null, false);
        if (error != null) {
            authState.setValue(AuthState.error(error));
            return;
        }

        authState.setValue(AuthState.loading());
        repo.login(email.trim(), password, new UserRepository.AuthCallback() {
            @Override public void onSuccess(FirebaseUser user) {
                authState.postValue(AuthState.success(user));
            }
            @Override public void onError(String message) {
                authState.postValue(AuthState.error(message));
            }
        });
    }


    public void register(String nombre, String email, String pass, String confirmPass, int edad, List<Integer> generos, Uri fotoUri) {
        String error = validate(email, pass, confirmPass, true);
        if (error != null) {
            authState.setValue(AuthState.error(error));
            return;
        }

        authState.setValue(AuthState.loading());

        repo.register(email, pass, new UserRepository.AuthCallback() {
            @Override
            public void onSuccess(FirebaseUser user) {

                if (fotoUri != null) {
                    subirFotoPerfilSupabase(user.getUid(), fotoUri, new OnImageUploadCallback() {
                        @Override
                        public void onComplete(String urlFinal) {
                            guardarUsuarioEnFirestore(user, nombre, email, edad, generos, urlFinal);
                        }
                        @Override
                        public void onError(String error) {

                            String fotoDefecto = "https://skeceyvvytlwjyrmlsik.supabase.co/storage/v1/object/public/perfiles/default.png";
                            guardarUsuarioEnFirestore(user, nombre, email, edad, generos, fotoDefecto);
                        }
                    });
                } else {

                    String fotoDefecto = "https://skeceyvvytlwjyrmlsik.supabase.co/storage/v1/object/public/perfiles/default.png";
                    guardarUsuarioEnFirestore(user, nombre, email, edad, generos, fotoDefecto);
                }
            }

            @Override
            public void onError(String message) {
                authState.postValue(AuthState.error(message));
            }
        });
    }
    private void guardarUsuarioEnFirestore(FirebaseUser user, String nombre, String email, int edad, List<Integer> generos, String urlFoto) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();


        Usuario nuevoUsuario = new Usuario(nombre, email, edad, generos,urlFoto,user.getUid());
        nuevoUsuario.setFotoPerfil(urlFoto);
        nuevoUsuario.setUid(user.getUid());

        db.collection("users").document(user.getUid())
                .set(nuevoUsuario)
                .addOnSuccessListener(aVoid -> {
                    authState.postValue(AuthState.success(user));
                })
                .addOnFailureListener(e -> {
                    authState.postValue(AuthState.error("Error Firestore: " + e.getMessage()));
                });
    }


    private void subirFotoPerfilSupabase(String uid, Uri uri, OnImageUploadCallback callback) {
        byte[] imageData;
        try {
            android.content.ContentResolver cr = getApplication().getContentResolver();
            java.io.InputStream inputStream = cr.openInputStream(uri);
            java.io.ByteArrayOutputStream byteBuffer = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStream.read(buffer)) != -1) {
                byteBuffer.write(buffer, 0, len);
            }
            imageData = byteBuffer.toByteArray();
        } catch (Exception e) {
            callback.onError("Error al procesar la imagen: " + e.getMessage());
            return;
        }

        String projectUrl = "https://skeceyvvytlwjyrmlsik.supabase.co";
        String supabaseKey = "sb_publishable_3OGLOUa_xV_bM_oMCW7C5Q_wZlov_fO";


        String supabaseUploadUrl = projectUrl + "/storage/v1/object/perfiles/" + uid + ".jpg";

        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient();
        okhttp3.RequestBody requestBody = okhttp3.RequestBody.create(
                okhttp3.MediaType.parse("image/jpeg"),
                imageData
        );

        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(supabaseUploadUrl)
                .addHeader("Authorization", "Bearer " + supabaseKey)
                .addHeader("apikey", supabaseKey)
                .addHeader("Content-Type", "image/jpeg")
                .put(requestBody)
                .build();

        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override
            public void onFailure(@NonNull okhttp3.Call call, @NonNull java.io.IOException e) {
                callback.onError(e.getMessage());
            }

            @Override
            public void onResponse(@NonNull okhttp3.Call call, @NonNull okhttp3.Response response) throws java.io.IOException {
                if (response.isSuccessful()) {

                    String urlPublica = projectUrl + "/storage/v1/object/public/perfiles/" + uid + ".jpg";
                    callback.onComplete(urlPublica);
                } else {
                    callback.onError("Error Supabase (" + response.code() + "): " + response.message());
                }
                response.close();
            }
        });
    }


    public interface OnImageUploadCallback {
        void onComplete(String url);
        void onError(String error);
    }

    public void cargarPeliculasPersonalizadas() {
        FirebaseUser currentUser = repo.getCurrentUser();
        if (currentUser == null) return;

        FirebaseFirestore db = FirebaseFirestore.getInstance();


        db.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {

                        List<Long> idsLong = (List<Long>) documentSnapshot.get("generosFavoritos");

                        if (idsLong != null && !idsLong.isEmpty()) {

                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < idsLong.size(); i++) {
                                sb.append(idsLong.get(i));
                                if (i < idsLong.size() - 1) sb.append(",");
                            }


                            repository.getPeliculasPorGeneros(sb.toString(), result -> {
                                Peliculas.postValue(result);
                            });
                        } else {
                            cargarPokedex();
                        }
                    }
                });
    }



    public void cargarDatosUsuario() {
        String uid = repo.getCurrentUser().getUid();
        FirebaseFirestore.getInstance().collection("users").document(uid).get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        Long edad = document.getLong("edad");
                        if (edad != null) edadUsuarioActual = edad.intValue();
                    }
                });
    }

    public int getEdadUsuarioActual() {
        return edadUsuarioActual;
    }


    private void guardarPerfilEnFirestore(FirebaseUser user, String nombreReal) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Map<String, Object> userData = new HashMap<>();

        userData.put("displayName", nombreReal);
        userData.put("email", user.getEmail());
        userData.put("createdAt", System.currentTimeMillis());

        db.collection("users").document(user.getUid()).set(userData);
    }

    public void loginConGoogle(String idToken) {
        authState.setValue(AuthState.loading());
        repo.loginConGoogle(idToken, new UserRepository.AuthCallback() {
            @Override
            public void onSuccess(FirebaseUser user) {
                authState.postValue(AuthState.success(user));
            }

            @Override
            public void onError(String message) {
                authState.postValue(AuthState.error(message));
            }
        });
    }

    public void resetPassword(String email) {
        if (email == null || email.trim().isEmpty()) {
            authState.setValue(AuthState.error("Introduce tu correo para el reset."));
            return;
        }

        repo.resetPassword(email.trim(), new UserRepository.AuthCallback() {
            @Override public void onSuccess(FirebaseUser user) {
                authState.postValue(AuthState.error("Correo de recuperación enviado."));
            }
            @Override public void onError(String message) {
                authState.postValue(AuthState.error(message));
            }
        });
    }

    private String validate(String email, String password, String confirmPassword, boolean isRegister) {
        if (email == null || email.trim().isEmpty()) return "El correo es obligatorio.";

        if (isRegister) {
            String emailPattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$";
            if (!email.matches(emailPattern)) return "Formato de correo electrónico no válido.";

            if (password == null || password.isEmpty()) return "La contraseña es obligatoria.";
            if (password.length() < 8) return "La contraseña debe tener al menos 8 caracteres.";
            if (!password.matches(".*[a-zA-Z].*")) return "La contraseña debe contener al menos una letra.";
            if (!password.matches(".*[0-9].*")) return "La contraseña debe contener al menos un número.";

            if (confirmPassword == null || !password.equals(confirmPassword)) {
                return "Las contraseñas no coinciden.";
            }
        }
        return null;
    }

    public void seleccionarAnimalDesdeFavoritos(PeliculaySerie fav) {
        Result peli = new Result();
        peli.setTitle(fav.getTitulo());
        peli.setPosterPath(fav.getURL());
        peli.setOverview(fav.getDescripcion());
        peli.setId(fav.getId());

        Peliseleccionada.setValue(peli);
        SerieSeleccionada.setValue(null);
    }

    public void seleccionarSeguimiento(Seguimiento seguimiento) {
        seguimientoSeleccionado.setValue(seguimiento);
    }

    public LiveData<Seguimiento> getSeguimientoSeleccionado() {
        return seguimientoSeleccionado;
    }

    public void seleccionarAnimal(Result animal) {
        Peliseleccionada.setValue(animal);
        SerieSeleccionada.setValue(null);
    }

    public void seleccionarAnimal2(Result2 animal) {
        SerieSeleccionada.setValue(animal);
        Peliseleccionada.setValue(null);
    }

    public void PeliculaySerie(PeliculaySerie peliculaySerie) {
        PeliculaySerie.setValue(peliculaySerie);
        Peliseleccionada.setValue(null);
        SerieSeleccionada.setValue(null);
    }

    public boolean isDialogoMostrado() {
        return dialogoMostrado;
    }

    public void setDialogoMostrado(boolean mostrado) {
        this.dialogoMostrado = mostrado;
    }

    public void comprobarPrimerIngreso() {
        primerIngreso.postValue(repository2.isPrimerIngreso());
    }

    public void comprobarIdioma() {
        idioma.postValue(repository2.hayidioma());
    }

    public void comprobarNOmbre(){
        nombre.postValue(repository2.haynombre());
    }

    public void actualizarPrimerIngreso() {
        repository2.setPrimerIngreso(false);
    }

    public void actualizarnombre(String nombre) {
        repository2.setnombre(nombre);
    }

    public void actualizaridioma(String nombre) {
        repository2.setIdioma(nombre);
    }

    public void actualizartema(String nombre) {
        repository2.setTema(nombre);
    }

    public MutableLiveData<Boolean> getPrimerIngreso() {
        return primerIngreso;
    }
    public MutableLiveData<String> getNombre() {
        return nombre;
    }
    public MutableLiveData<String> getIidoma() {
        return idioma;
    }

    public PeliculaySerie obtenerPendienteAleatoria(List<PeliculaySerie> lista) {
        if (lista == null || lista.isEmpty()) return null;
        int index = (int) (Math.random() * lista.size());
        return lista.get(index);
    }

    public void buscar(String name) {
        repository.getPelicula(name, result -> {
            Peliculas.postValue(result);
        });
    }

    public void buscar2(String name) {
        repository.getSerie(name, result -> {
            Series.postValue(result);
        });
    }

    public void cargarPokedex() {
        repository.getPeliculas(result -> {
            Peliculas.postValue(result);
        });
    }

    public void cargarPokedex2() {
        repository.getPeliculas2(result -> {
            Series.postValue(result);
        });
    }

    public void reset(){
        Peliculas.postValue(Resource.success(new ArrayList<>()));
        repository.Reset();
    }
}