package es.iesagora.ejercicio6;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.data.Seguimiento;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;

public class CatalogoViewModel extends AndroidViewModel {
    private RepositoryDatabase repositoryDatabase;
    private boolean dialogoMostrado = false;
    private final PreferencesRepository repository2;
    private MutableLiveData<Boolean> primerIngreso = new MutableLiveData<>();
    private MutableLiveData<String> nombre = new MutableLiveData<>();

    private MutableLiveData<String> idioma = new MutableLiveData<>();

    private MutableLiveData<Boolean> tema = new MutableLiveData<>();
    private final APIRepository repository;
    public MutableLiveData<Result> Peliseleccionada = new MutableLiveData<>();
    public MutableLiveData<Result2> SerieSeleccionada = new MutableLiveData<>();
    public MutableLiveData<PeliculaySerie> PeliculaySerie = new MutableLiveData<>();

    MutableLiveData<Resource<Result>> informacionPelicula = new MutableLiveData<>();
    private MutableLiveData<Seguimiento> seguimientoSeleccionado = new MutableLiveData<>();
    MutableLiveData<Resource<Result2>> informacionSerie = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Result>>> Peliculas = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Result2>>> Series = new MutableLiveData<>();
    public CatalogoViewModel(@NonNull Application application) {
        super(application);

        repository = new APIRepository();
        repository2 = new PreferencesRepository(application);
        repositoryDatabase = new RepositoryDatabase(application);
        comprobarNOmbre();
        comprobarPrimerIngreso();
    }

    public LiveData<List<PeliculaySerie>> ObtenerPeliculas() {

        return repositoryDatabase.ObtenerPeliculas();
    }
    public void seleccionarAnimalDesdeFavoritos(PeliculaySerie fav) {

        Result peli = new Result();


        peli.setTitle(fav.getTitulo());
        peli.setPosterPath(fav.getURL());
        peli.setOverview(fav.getDescripcion());



        Peliseleccionada.setValue(peli);


        SerieSeleccionada.setValue(null);
    }

    public void insertarPelicula(PeliculaySerie peliculaySerie) {
        repositoryDatabase.insertar(peliculaySerie);
    }

    public void comprobarPrimerIngreso() {
        primerIngreso.postValue(repository2.isPrimerIngreso());
    }

    public void comprobarIdioma() {
        idioma.postValue(repository2.hayidioma());
    }



    public void comprobarNOmbre(){
        nombre.postValue(repository2.haynombre());
    }

    /**
     * Método que almacena en las SharedPreferences que el usuario
     * ya realizó el primer ingreso
     */
    public void actualizarPrimerIngreso() {
        repository2.setPrimerIngreso(false);
    }

    public void actualizarnombre(String nombre) {
        repository2.setnombre(nombre);
    }

    public void actualizaridioma(String nombre) {
        repository2.setIdioma(nombre);
    }

    public void actualizartema(String nombre) {
        repository2.setTema(nombre);
    }

    ///  Getter para el LiveData
    public MutableLiveData<Boolean> getPrimerIngreso() {
        return primerIngreso;
    }
    public MutableLiveData<String> getNombre() {
        return nombre;
    }

    public MutableLiveData<String> getIidoma() {
        return idioma;
    }

    public void seleccionarSeguimiento(Seguimiento seguimiento) {
        seguimientoSeleccionado.setValue(seguimiento);
    }

    public LiveData<Seguimiento> getSeguimientoSeleccionado() {
        return seguimientoSeleccionado;
    }

    public LiveData<List<Seguimiento>> ObtenerSerie() {
      return repositoryDatabase.ObtenerSeries();
    }

    public void insertarSerie(Seguimiento seguimiento) {
        repositoryDatabase.insertarSerie(seguimiento);
    }

    public boolean isDialogoMostrado() {
        return dialogoMostrado;
    }

    public void setDialogoMostrado(boolean mostrado) {
        this.dialogoMostrado = mostrado;
    }

    // Método para obtener una peli/serie aleatoria de la DB
    public PeliculaySerie obtenerPendienteAleatoria(List<PeliculaySerie> lista) {
        if (lista == null || lista.isEmpty()) return null;
        int index = (int) (Math.random() * lista.size());
        return lista.get(index);
    }


    public void buscar(String name) {
    repository.getPelicula(name, result -> {

            Peliculas.postValue(result);
        });
    }


    public void buscar2(String name) {
       repository.getSerie(name, result -> {

            Series.postValue(result);
        });
    }
    public void cargarPokedex() {

        repository.getPeliculas(result -> {

            Peliculas.postValue(result);
        });
    }
    public void cargarPokedex2() {

        repository.getPeliculas2(result -> {

            Series.postValue(result);
        });
    }
    public void seleccionarAnimal(Result animal) {
        Peliseleccionada.setValue(animal);
        SerieSeleccionada.setValue(null);
    }
    public void seleccionarAnimal2(Result2 animal) {
        SerieSeleccionada.setValue(animal);
        Peliseleccionada.setValue(null);
    }

    public void PeliculaySerie(PeliculaySerie peliculaySerie) {
        PeliculaySerie.setValue(peliculaySerie);
        Peliseleccionada.setValue(null);
        SerieSeleccionada.setValue(null);
    }
    public void reset(){
        Peliculas.postValue(Resource.success(new ArrayList<>()));
        repository.Reset();
    }
}

