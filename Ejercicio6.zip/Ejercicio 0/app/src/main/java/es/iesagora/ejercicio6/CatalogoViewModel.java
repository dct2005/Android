package es.iesagora.ejercicio6;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;

import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.data.Seguimiento;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;

public class CatalogoViewModel extends AndroidViewModel {
    private RepositoryDatabase repositoryDatabase;
    private final APIRepository repository;
    public MutableLiveData<Result> animalSeleccionado = new MutableLiveData<>();
    public MutableLiveData<Result2> animalSeleccionado2 = new MutableLiveData<>();
    public MutableLiveData<PeliculaySerie> PeliculaySerie = new MutableLiveData<>();
    // LiveData observado por el Fragment.
    // Contendrá Loading, Success o Error, junto al dato correspondiente.
    MutableLiveData<Resource<Result>> informacionPokemon = new MutableLiveData<>();
    MutableLiveData<Resource<Result2>> informacionPokemon2 = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Result>>> Digidex = new MutableLiveData<>();
    public MutableLiveData<Resource<List<Result2>>> Digidex2 = new MutableLiveData<>();
    public CatalogoViewModel(@NonNull Application application) {
        super(application);
        // Inicializamos el Repository, capa encargada de hablar con la API
        repository = new APIRepository();
        repositoryDatabase = new RepositoryDatabase(application);
    }

    public LiveData<List<PeliculaySerie>> ObtenerPeliculas() {
        // Devolvemos el LiveData recibido y pondremos un observador sobre el método en la View
        return repositoryDatabase.ObtenerPeliculas();
    }

    public void insertarPelicula(PeliculaySerie peliculaySerie) {
        repositoryDatabase.insertar(peliculaySerie);
    }

    public LiveData<List<Seguimiento>> ObtenerSerie() {
        // Devolvemos el LiveData recibido y pondremos un observador sobre el método en la View
        return repositoryDatabase.ObtenerSeries();
    }

    public void insertarSerie(Seguimiento seguimiento) {
        repositoryDatabase.insertarSerie(seguimiento);
    }

    // Método usado por el Fragment para iniciar una búsqueda
    public void buscarPokemon(String name) {

        // Realizamos la búsqueda mediante el Repository
        // y recibimos la respuesta a través del callback
        repository.getPokemon(name, new APIRepository.DigimonCallback() {
            @Override
            public void onResult(Resource<Result> result) {
                // Publicamos el resultado dentro del LiveData
                informacionPokemon.postValue(result);
            }
        });
    }

    public void buscarPokemon2(String name) {

        // Realizamos la búsqueda mediante el Repository
        // y recibimos la respuesta a través del callback
        repository.getPokemon2(name, new APIRepository.DigimonCallback2() {
            @Override
            public void onResult(Resource<Result2> result) {
                // Publicamos el resultado dentro del LiveData
                informacionPokemon2.postValue(result);
            }
        });
    }
    public void cargarPokedex() {

        repository.getPeliculas(result -> {
            // Publicamos los resultados en el MLiveData
            Digidex.postValue(result);
        });
    }
    public void cargarPokedex2() {

        repository.getPeliculas2(result -> {
            // Publicamos los resultados en el MLiveData
            Digidex2.postValue(result);
        });
    }
    public void seleccionarAnimal(Result animal) {
        animalSeleccionado.setValue(animal);
        animalSeleccionado2.setValue(null);
    }
    public void seleccionarAnimal2(Result2 animal) {
        animalSeleccionado2.setValue(animal);
        animalSeleccionado.setValue(null);
    }

    public void PeliculaySerie(PeliculaySerie peliculaySerie) {
        PeliculaySerie.setValue(peliculaySerie);
        animalSeleccionado.setValue(null);
        animalSeleccionado2.setValue(null);
    }
    public void reset(){
        Digidex.postValue(Resource.success(new ArrayList<>()));
        repository.Reset();
    }
}

