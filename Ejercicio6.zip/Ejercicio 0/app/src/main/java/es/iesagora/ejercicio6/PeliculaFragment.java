package es.iesagora.ejercicio6;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import es.iesagora.ejercicio6.databinding.FragmentCatalogoBinding;

public class PeliculaFragment extends Fragment {

    private FragmentCatalogoBinding binding;
    private CatalogoViewModel viewModel;
    private CatalogoAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCatalogoBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 1. PRIMERO: Instanciamos el ViewModel (si no, sería null)
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);
        viewModel.cargarDatosUsuario();

        // 2. SEGUNDO: Configuramos el RecyclerView pasándole el ViewModel
        configurarRecyclerView();

        // 3. TERCERO: Observamos los cambios
        observarPokedex();
        configurarPaginacion();

        // 4. LÓGICA DE CARGA (Evita recargar al girar pantalla)
        if (viewModel.Peliculas.getValue() == null || viewModel.Peliculas.getValue().data == null) {
            viewModel.cargarPokedex();
        }
    }

    private void configurarRecyclerView() {

        adapter = new CatalogoAdapter(requireContext(), viewModel);

        binding.recyclerPeliculas.setAdapter(adapter);
        binding.recyclerPeliculas.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    private void observarPokedex() {
        viewModel.Peliculas.observe(getViewLifecycleOwner(), resource -> {
            if (resource == null) return;

            switch (resource.status) {
                case LOADING:
                    if (adapter.getItemCount() == 0) {
                        binding.progressLoadingPeliculas.setVisibility(View.VISIBLE);
                        binding.recyclerPeliculas.setVisibility(View.GONE);
                    }
                    break;

                case SUCCESS:
                    binding.progressLoadingPeliculas.setVisibility(View.GONE);
                    binding.recyclerPeliculas.setVisibility(View.VISIBLE);
                    if (resource.data != null) {

                        adapter.addPeliculaList(resource.data);
                    }
                    break;

                case ERROR:
                    binding.progressLoadingPeliculas.setVisibility(View.GONE);
                    if (adapter.getItemCount() == 0) {
                        binding.tvErrorPeliculas.setText(resource.message);
                        binding.layoutErrorPeliculas.setVisibility(View.VISIBLE);
                    } else {
                        Toast.makeText(getContext(), "Error: " + resource.message, Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
        });
    }

    private void configurarPaginacion() {
        binding.recyclerPeliculas.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    if (!recyclerView.canScrollVertically(1)) {
                        viewModel.cargarPokedex();
                    }
                }
            }
        });
    }
}