package es.iesagora.ejercicio6;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import es.iesagora.ejercicio6.databinding.FragmentPendientesBinding;


public class PendientesFragment extends Fragment {

    FragmentPendientesBinding binding;
    private CatalogoViewModel viewModel;
    private CatalogoAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return (binding = FragmentPendientesBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // 1. PRIMERO: Instanciamos el ViewModel (si no, sería null)
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);

        // 2. SEGUNDO: Configuramos el RecyclerView pasándole el ViewModel
        configurarRecyclerView();

        // 3. TERCERO: Observamos los cambios
        observarPokedex();
        configurarPaginacion();


        if (viewModel.Peliculas.getValue() == null || viewModel.Peliculas.getValue().data == null) {
            viewModel.cargarPokedex2();
        }
    }

    private void configurarRecyclerView() {

        adapter = new CatalogoAdapter(requireContext(), viewModel);

        binding.recyclerPokedex.setAdapter(adapter);
        binding.recyclerPokedex.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    private void observarPokedex() {
        viewModel.ObtenerPeliculas().observe(getViewLifecycleOwner(), lista -> {
            if (lista == null || lista.isEmpty()) {

                binding.progressLoadingPokedex.setVisibility(View.GONE);
                binding.layoutErrorPokedex.setVisibility(View.VISIBLE); // El layout de las palomitas [cite: 37, 40]
                binding.recyclerPokedex.setVisibility(View.GONE);
            } else {

                binding.layoutErrorPokedex.setVisibility(View.GONE);
                binding.progressLoadingPokedex.setVisibility(View.GONE);
                binding.recyclerPokedex.setVisibility(View.VISIBLE);


                adapter.establecerLista(lista);
            }
        });
    }

    private void configurarPaginacion() {
        binding.recyclerPokedex.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    if (!recyclerView.canScrollVertically(1)) {
                        viewModel.cargarPokedex2();
                    }
                }
            }
        });
    }
    }







