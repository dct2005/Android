package es.iesagora.ejercicio6;

import static es.iesagora.ejercicio6.Resource.Status.ERROR;
import static es.iesagora.ejercicio6.Resource.Status.LOADING;
import static es.iesagora.ejercicio6.Resource.Status.SUCCESS;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.List;

import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.databinding.FragmentPendientesBinding;


public class PendientesFragment extends Fragment {

    FragmentPendientesBinding binding;
    private CatalogoViewModel viewModel;
    private CatalogoAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return (binding = FragmentPendientesBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // 1. PRIMERO: Instanciamos el ViewModel (si no, sería null)
        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);

        // 2. SEGUNDO: Configuramos el RecyclerView pasándole el ViewModel
        configurarRecyclerView();

        // 3. TERCERO: Observamos los cambios
        observarPokedex();
        configurarPaginacion();

        // 4. LÓGICA DE CARGA (Evita recargar al girar pantalla)
        if (viewModel.Digidex.getValue() == null || viewModel.Digidex.getValue().data == null) {
            viewModel.cargarPokedex2();
        }
    }

    private void configurarRecyclerView() {
        // AQUÍ ESTÁ EL CAMBIO:
        // Pasamos el contexto y el viewModel al constructor del Adapter
        adapter = new CatalogoAdapter(requireContext(), viewModel);

        binding.recyclerPokedex.setAdapter(adapter);
        binding.recyclerPokedex.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    private void observarPokedex() {
        viewModel.ObtenerPeliculas().observe(getViewLifecycleOwner(), lista -> {
            if (lista == null || lista.isEmpty()) {
                // MOSTRAR ESTADO VACÍO (Requisito de la actividad)
                binding.progressLoadingPokedex.setVisibility(View.GONE);
                binding.layoutErrorPokedex.setVisibility(View.VISIBLE); // El layout de las palomitas [cite: 37, 40]
                binding.recyclerPokedex.setVisibility(View.GONE);
            } else {
                // MOSTRAR LISTA
                binding.layoutErrorPokedex.setVisibility(View.GONE);
                binding.progressLoadingPokedex.setVisibility(View.GONE);
                binding.recyclerPokedex.setVisibility(View.VISIBLE);

                // Pasamos la lista directamente al adapter
                adapter.establecerLista(lista);
            }
        });
    }

    private void configurarPaginacion() {
        binding.recyclerPokedex.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    if (!recyclerView.canScrollVertically(1)) {
                        viewModel.cargarPokedex2();
                    }
                }
            }
        });
    }
    }







