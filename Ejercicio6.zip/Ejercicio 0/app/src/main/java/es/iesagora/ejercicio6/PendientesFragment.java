package es.iesagora.ejercicio6;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import es.iesagora.ejercicio6.databinding.FragmentPendientesBinding;


public class PendientesFragment extends Fragment {

    FragmentPendientesBinding binding;
    private CatalogoViewModel viewModel;
    private CatalogoAdapter adapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return (binding = FragmentPendientesBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);


        configurarRecyclerView();


        observarPokedex();
        configurarPaginacion();


        if (viewModel.Peliculas.getValue() == null || viewModel.Peliculas.getValue().data == null) {
            viewModel.cargarPokedex2();
        }
    }

    private void configurarRecyclerView() {

        adapter = new CatalogoAdapter(requireContext(), viewModel);

        binding.recyclerPendientes.setAdapter(adapter);
        binding.recyclerPendientes.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    private void observarPokedex() {
        viewModel.ObtenerPeliculas().observe(getViewLifecycleOwner(), lista -> {
            if (lista == null || lista.isEmpty()) {

                binding.progressLoadingPendientes.setVisibility(View.GONE);
                binding.layoutErrorPendientes.setVisibility(View.VISIBLE);
                binding.recyclerPendientes.setVisibility(View.GONE);
            } else {

                binding.layoutErrorPendientes.setVisibility(View.GONE);
                binding.progressLoadingPendientes.setVisibility(View.GONE);
                binding.recyclerPendientes.setVisibility(View.VISIBLE);


                adapter.establecerLista(lista);
            }
        });
    }

    private void configurarPaginacion() {
        binding.recyclerPendientes.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    if (!recyclerView.canScrollVertically(1)) {
                        viewModel.cargarPokedex2();
                    }
                }
            }
        });
    }
    }







