package es.iesagora.ejercicio6;

import android.app.AlertDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import es.iesagora.ejercicio6.databinding.FragmentSettingsBinding;

public class SettingsFragment extends Fragment {

    private CatalogoViewModel viewModel;
    private FragmentSettingsBinding binding;

    private NavController navController;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return (binding = FragmentSettingsBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(CatalogoViewModel.class);
        navController = Navigation.findNavController(view);
        configurarSpinnerIdiomas();
        // Invocamos el método que consulta el valor almacenado
        viewModel.comprobarPrimerIngreso();

        binding.btnSave.setOnClickListener(v -> {

                viewModel.actualizarnombre(binding.etUsername.getText().toString());
        viewModel.actualizaridioma(binding.spinnerLanguage.toString());
        viewModel.actualizartema(binding.themeContainer.toString());
        navController.navigate(R.id.action_settingsFragment_to_InicioFragment);
    });
    }


    private void configurarSpinnerIdiomas() {
        // Creamos el adaptador usando el array que definimos en strings.xml
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.idiomas_array,
                android.R.layout.simple_spinner_item // Diseño simple por defecto
        );

        // Especificamos el diseño que aparecerá cuando se desplieguen las opciones
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Se lo aplicamos al Spinner a través del binding
        binding.spinnerLanguage.setAdapter(adapter);
    }







}