package es.iesagora.ejercicio6;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import es.iesagora.ejercicio6.databinding.FragmentSettingsBinding;

public class SettingsFragment extends Fragment {

    private CatalogoViewModel viewModel;
    private FragmentSettingsBinding binding;
    private boolean primeraCargaSpinner = true;

    private NavController navController;
    private Uri nuevaUriSeleccionada;


    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    nuevaUriSeleccionada = result.getData().getData();

                    binding.ivProfileSettings.setImageURI(nuevaUriSeleccionada);

                    viewModel.actualizarFotoPerfil(nuevaUriSeleccionada);
                }
            }
    );

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return (binding = FragmentSettingsBinding.inflate(inflater, container, false)).getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(CatalogoViewModel.class);
        navController = Navigation.findNavController(view);
        configurarSpinnerIdiomas();
        cargarDatosUsuarioActual();
        viewModel.comprobarPrimerIngreso();

        binding.ivProfileSettings.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            galleryLauncher.launch(intent);
        });
        binding.btnSave.setOnClickListener(v -> {
            if (nuevaUriSeleccionada != null) {
                viewModel.actualizarFotoPerfil(nuevaUriSeleccionada);
            }
            viewModel.actualizarnombre(binding.etUsername.getText().toString());

            String langCode = (binding.spinnerLanguage.getSelectedItemPosition() == 0) ? "es" : "en";
            viewModel.actualizaridioma(langCode);

            mostrarDialogoExito();
        });


        binding.btnCerrarSesion.setOnClickListener(v -> {

            viewModel.logout();


            Intent intent = new Intent(getActivity(), UserActivity.class);


            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
            getActivity().finish();
        });


    }


    private void configurarSpinnerIdiomas() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                requireContext(),
                R.array.idiomas_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerLanguage.setAdapter(adapter);


        String idiomaActual = getResources().getConfiguration().getLocales().get(0).getLanguage();
        if (idiomaActual.equals("en")) {
            binding.spinnerLanguage.setSelection(1);
        } else {
            binding.spinnerLanguage.setSelection(0);
        }

        primeraCargaSpinner = true;

        binding.spinnerLanguage.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (primeraCargaSpinner) {
                    primeraCargaSpinner = false;
                    return;
                }

                String langCode = (position == 0) ? "es" : "en";

                String currentLang = getResources().getConfiguration().getLocales().get(0).getLanguage();

                if (!currentLang.equals(langCode)) {
                    cambiarIdiomaManual(langCode);
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }
    private void cargarDatosUsuarioActual() {
        FirebaseUser user = viewModel.getCurrentUser();
        if (user != null) {
            FirebaseFirestore.getInstance().collection("users").document(user.getUid())
                    .get()
                    .addOnSuccessListener(document -> {
                        if (!isAdded() || getActivity() == null) return;
                        if (document.exists()) {
                            String nombre = document.getString("nombre");
                            String fotoUrl = document.getString("fotoPerfil");

                            binding.etUsername.setText(nombre);


                            if (fotoUrl != null && !fotoUrl.isEmpty()) {
                                Glide.with(this)
                                        .load(fotoUrl)
                                        .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.NONE)
                                        .skipMemoryCache(true)
                                        .circleCrop()
                                        .placeholder(android.R.drawable.ic_menu_gallery)
                                        .error(android.R.drawable.stat_notify_error)
                                        .into(binding.ivProfileSettings);
                            }
                        }
                    });
        }
    }
    private void mostrarDialogoExito() {
        new AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.dialog_success))
                .setMessage(getString(R.string.msg_saved_ok))
                .setPositiveButton(getString(R.string.btn_accept), (dialog, which) -> {
                    navController.navigate(R.id.action_settingsFragment_to_InicioFragment);
                })
                .setCancelable(false)
                .show();
    }
    private void cambiarIdiomaManual(String code) {
        java.util.Locale locale = new java.util.Locale(code);
        java.util.Locale.setDefault(locale);

        android.content.res.Resources res = getResources();
        android.content.res.Configuration config = res.getConfiguration();
        config.setLocale(locale);


        res.updateConfiguration(config, res.getDisplayMetrics());


        if (getActivity() != null) {
            getActivity().recreate();
        }
    }







}