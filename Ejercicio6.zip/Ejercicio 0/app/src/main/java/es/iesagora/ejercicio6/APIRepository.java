
package es.iesagora.ejercicio6;

import java.util.List;

import es.iesagora.ejercicio6.model.Example;
import es.iesagora.ejercicio6.model.Example2;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;
import retrofit2.Call;
import retrofit2.Response;

public class APIRepository {
    private final DigiApi api;



    private int PAGE_PELICULAS = 1;
    private int PAGE_SERIES = 1;
    public APIRepository() {

        api = RetrofitClient.getClient().create(DigiApi.class);

    }

    public interface PeliculaCallback {
        void onResult(Resource<Result> result);
    }

    public interface SerieCallback2 {
        void onResult(Resource<Result2> result);
    }
    public interface PeliculasCallback {

        void onResult(Resource<List<Result>> result);
    }
    public interface SeriesCallback2 {

        void onResult(Resource<List<Result2>> result);
    }
    public void getPelicula(String name, PeliculasCallback callback) {
        callback.onResult(Resource.loading());

        api.buscarPeliculaPorNombre(name).enqueue(new retrofit2.Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, Response<Example> response) {
                if (response.isSuccessful() && response.body() != null) {
                    callback.onResult(Resource.success(response.body().getResults()));
                }
            }
            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                callback.onResult(Resource.error(t.getMessage()));
            }
        });
    }
    public void getSerie(String name, SeriesCallback2 callback) {
        callback.onResult(Resource.loading());


        api.buscarSeriePorNombre(name.toLowerCase()).enqueue(new retrofit2.Callback<Example2>() {
            @Override
            public void onResponse(Call<Example2> call, Response<Example2> response) {
                if (response.isSuccessful() && response.body() != null) {

                    List<Result2> lista = response.body().getResults();

                    callback.onResult(Resource.success(lista));
                } else {
                    callback.onResult(Resource.error("Serie no encontrada"));
                }
            }

            @Override
            public void onFailure(Call<Example2> call, Throwable t) {
                callback.onResult(Resource.error("Error de conexión: " + t.getMessage()));
            }
        });
    }
    public void getPeliculas(PeliculasCallback callback) {


        callback.onResult(Resource.loading());

        api.getPeliculas(PAGE_PELICULAS).enqueue(new retrofit2.Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, Response<Example> response) {
                if (response.isSuccessful() && response.body() != null) {

                    List<Result> lista = response.body().getResults();
                    callback.onResult(Resource.success(lista));
                } else {
                    callback.onResult(Resource.error("No se pudo cargar la Pokédex"));
                }


                PAGE_PELICULAS += 1;
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                callback.onResult(Resource.error("Error de red: " + t.getMessage()));
            }
        });
    }
    public void getPeliculas2(SeriesCallback2 callback) {


        callback.onResult(Resource.loading());

        api.getPeliculas2(PAGE_SERIES).enqueue(new retrofit2.Callback<Example2>() {
            @Override
            public void onResponse(Call<Example2> call, Response<Example2> response) {
                if (response.isSuccessful() && response.body() != null) {

                    List<Result2> lista = response.body().getResults();
                    callback.onResult(Resource.success(lista));
                } else {
                    callback.onResult(Resource.error("No se pudo cargar la Pokédex"));
                }


                PAGE_SERIES += 1;
            }

            @Override
            public void onFailure(Call<Example2> call, Throwable t) {
                callback.onResult(Resource.error("Error de red: " + t.getMessage()));
            }
        });
    }

    public void Reset(){
        PAGE_PELICULAS = 1;
        PAGE_SERIES = 1;
    }
}
