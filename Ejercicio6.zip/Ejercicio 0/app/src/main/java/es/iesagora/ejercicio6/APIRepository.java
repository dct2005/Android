// EN: app/src/main/java/es/iesagora/ejercicio6/DigimonRepository.java
package es.iesagora.ejercicio6;

import java.util.List; // <--- IMPORTANTE AÑADIR ESTO

import es.iesagora.ejercicio6.model.Example;
import es.iesagora.ejercicio6.model.Example2;
import es.iesagora.ejercicio6.model.Result;
import es.iesagora.ejercicio6.model.Result2;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class APIRepository {
    private final DigiApi api;



    private int PAGE_PELICULAS = 1;
    private int PAGE_SERIES = 1;
    public APIRepository() {

        api = RetrofitClient.getClient().create(DigiApi.class);

    }

    public interface DigimonCallback {
        void onResult(Resource<Result> result);
    }

    public interface DigimonCallback2 {
        void onResult(Resource<Result2> result);
    }
    public interface PokedexCallback {
        // Directamente devolvemos la lista de Pokédex para que sea más sencillo de procesar
        // Por eso está la clase PokedexResponse.PokedexEntry
        void onResult(Resource<List<Result>> result);
    }
    public interface PokedexCallback2 {
        // Directamente devolvemos la lista de Pokédex para que sea más sencillo de procesar
        // Por eso está la clase PokedexResponse.PokedexEntry
        void onResult(Resource<List<Result2>> result);
    }
    public void getPokemon(String name, DigimonCallback callback) {
        // 1. Notificamos carga
        callback.onResult(Resource.loading());


        api.getPokemonByName(name.toLowerCase()).enqueue(new Callback<Result>() {

            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                // 3. Comprobamos éxito y cuerpo no nulo
                if (response.isSuccessful() && response.body() != null) {

                    callback.onResult(Resource.success(response.body()));
                } else {

                    callback.onResult(Resource.error("Digimon no encontrado (Error: " + response.code() + ")"));
                }
            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {
                // Error de red o error de conversión (JSON mal formado)
                callback.onResult(Resource.error("Error de conexión: " + t.getMessage()));
            }
        });
    }
    public void getPokemon2(String name, DigimonCallback2 callback) {
        // 1. Notificamos carga
        callback.onResult(Resource.loading());


        api.getPokemonByName2(name.toLowerCase()).enqueue(new Callback<Result2>() {

            @Override
            public void onResponse(Call<Result2> call, Response<Result2> response) {
                // 3. Comprobamos éxito y cuerpo no nulo
                if (response.isSuccessful() && response.body() != null) {

                    callback.onResult(Resource.success(response.body()));
                } else {

                    callback.onResult(Resource.error("Digimon no encontrado (Error: " + response.code() + ")"));
                }
            }

            @Override
            public void onFailure(Call<Result2> call, Throwable t) {
                // Error de red o error de conversión (JSON mal formado)
                callback.onResult(Resource.error("Error de conexión: " + t.getMessage()));
            }
        });
    }
    public void getPeliculas(PokedexCallback callback) {

        // Avisamos de que empieza la carga
        callback.onResult(Resource.loading());

        api.getPeliculas(PAGE_PELICULAS).enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, Response<Example> response) {
                if (response.isSuccessful() && response.body() != null) {

                    List<Result> lista = response.body().getResults();
                    callback.onResult(Resource.success(lista));
                } else {
                    callback.onResult(Resource.error("No se pudo cargar la Pokédex"));
                }

                // Incrementamos el offset
                PAGE_PELICULAS += 1;
            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                callback.onResult(Resource.error("Error de red: " + t.getMessage()));
            }
        });
    }
    public void getPeliculas2(PokedexCallback2 callback) {

        // Avisamos de que empieza la carga
        callback.onResult(Resource.loading());

        api.getPeliculas2(PAGE_SERIES).enqueue(new Callback<Example2>() {
            @Override
            public void onResponse(Call<Example2> call, Response<Example2> response) {
                if (response.isSuccessful() && response.body() != null) {

                    List<Result2> lista = response.body().getResults();
                    callback.onResult(Resource.success(lista));
                } else {
                    callback.onResult(Resource.error("No se pudo cargar la Pokédex"));
                }

                // Incrementamos el offset
                PAGE_SERIES += 1;
            }

            @Override
            public void onFailure(Call<Example2> call, Throwable t) {
                callback.onResult(Resource.error("Error de red: " + t.getMessage()));
            }
        });
    }

    public void Reset(){
        PAGE_PELICULAS = 1;
        PAGE_SERIES = 1;
    }
}
