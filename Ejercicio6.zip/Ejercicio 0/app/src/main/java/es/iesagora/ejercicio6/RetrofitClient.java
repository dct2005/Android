package es.iesagora.ejercicio6;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;public class RetrofitClient {
    private static Retrofit retrofit = null;

    public static Retrofit getClient() {
        if (retrofit == null) {

            // 1. Construimos el cliente OkHttp con nuestro Interceptor
            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(new AuthInterceptor()) // <--- AQUÍ ESTÁ LA MAGIA
                    .build();

            // 2. Construimos Retrofit usando ese cliente
            retrofit = new Retrofit.Builder()
                    .baseUrl("https://api.themoviedb.org/3/") // URL base de TMDB
                    .client(client) // <--- ASIGNAMOS EL CLIENTE AQUÍ
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }
}
