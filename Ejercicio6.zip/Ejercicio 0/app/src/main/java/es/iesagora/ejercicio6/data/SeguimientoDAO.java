package es.iesagora.ejercicio6.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface SeguimientoDAO {
    @Insert
    void insertar(Seguimiento seguimiento);

    @Update
    void actualizar(Seguimiento seguimiento);

    @Delete
    void eliminar(Seguimiento seguimiento);

    @Query("SELECT * FROM Seguimiento ORDER BY titulo ASC")
    LiveData<List<Seguimiento>> obtenerTodos();

    @Query("SELECT * FROM Seguimiento WHERE titulo = :titulo LIMIT 1")
    LiveData<Seguimiento> buscarPorNombre(String titulo);
}
