package es.iesagora.ejercicio6;

import android.app.Application;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.List;
import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.data.Seguimiento;

public class RepositoryDatabase {

    private final FirebaseFirestore db;
    private final FirebaseAuth auth;

    public RepositoryDatabase(Application application) {
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }

    public void insertar(PeliculaySerie pelicula) {
        if (auth.getCurrentUser() == null) return;
        String uid = auth.getCurrentUser().getUid();

        db.collection("users")
                .document(uid)
                .collection("pendientes")
                .document(String.valueOf(pelicula.getId()))
                .set(pelicula);
    }

    public void insertarSerie(Seguimiento serie) {
        if (auth.getCurrentUser() == null) return;
        String uid = auth.getCurrentUser().getUid();

        db.collection("users")
                .document(uid)
                .collection("seguimiento")
                .document(String.valueOf(serie.getId()))
                .set(serie);
    }

    public LiveData<List<PeliculaySerie>> ObtenerPeliculas() {
        MutableLiveData<List<PeliculaySerie>> data = new MutableLiveData<>();
        if (auth.getCurrentUser() == null) return data;

        db.collection("users")
                .document(auth.getCurrentUser().getUid())
                .collection("pendientes")
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null) return;
                    List<PeliculaySerie> lista = new ArrayList<>();
                    for (DocumentSnapshot doc : value.getDocuments()) {
                        PeliculaySerie p = doc.toObject(PeliculaySerie.class);
                        if (p != null) lista.add(p);
                    }
                    data.setValue(lista);
                });
        return data;
    }

    public interface ExistenciaCallback {
        void onCallback(boolean existe);
    }

    public void existePelicula(String id, ExistenciaCallback callback) {
        if (auth.getCurrentUser() == null) {
            callback.onCallback(false);
            return;
        }
        db.collection("users")
                .document(auth.getCurrentUser().getUid())
                .collection("pendientes")
                .document(id)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        callback.onCallback(task.getResult().exists());
                    } else {
                        callback.onCallback(false);
                    }
                });
    }

    public void existeSerie(String id, ExistenciaCallback callback) {
        if (auth.getCurrentUser() == null) {
            callback.onCallback(false);
            return;
        }
        db.collection("users")
                .document(auth.getCurrentUser().getUid())
                .collection("seguimiento")
                .document(id)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        callback.onCallback(task.getResult().exists());
                    } else {
                        callback.onCallback(false);
                    }
                });
    }

    public LiveData<List<Seguimiento>> ObtenerSeries() {
        MutableLiveData<List<Seguimiento>> data = new MutableLiveData<>();
        if (auth.getCurrentUser() == null) return data;

        db.collection("users")
                .document(auth.getCurrentUser().getUid())
                .collection("seguimiento")
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null) return;
                    List<Seguimiento> lista = new ArrayList<>();
                    for (DocumentSnapshot doc : value.getDocuments()) {
                        Seguimiento s = doc.toObject(Seguimiento.class);
                        if (s != null) lista.add(s);
                    }
                    data.setValue(lista);
                });
        return data;
    }
}