package es.iesagora.ejercicio6;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import es.iesagora.ejercicio6.data.Database;
import es.iesagora.ejercicio6.data.PeliculaySerie;
import es.iesagora.ejercicio6.data.PeliculaDAO;
import es.iesagora.ejercicio6.data.Seguimiento;
import es.iesagora.ejercicio6.data.SeguimientoDAO;

public class RepositoryDatabase {
    private PeliculaDAO peliculaDAO;
    private SeguimientoDAO seguimientoDAO;
    private Executor executor;

    public RepositoryDatabase(Application application) {

        Database db = Database.getInstance(application);

        peliculaDAO = db.peliculaDAO();


        seguimientoDAO = db.seguimientoDAO();


        executor = Executors.newSingleThreadExecutor();
    }

    public void insertar(PeliculaySerie peliculaySerie) {
        executor.execute(() -> {
            peliculaDAO.insertar(peliculaySerie);
        });
    }

    public void insertarSerie(Seguimiento seguimiento) {
        executor.execute(() -> {
            seguimientoDAO.insertar(seguimiento);
        });
    }


    public LiveData<List<PeliculaySerie>> ObtenerPeliculas() {
        return peliculaDAO.obtenerTodos();
    }

    public LiveData<List<Seguimiento>> ObtenerSeries() {
        return seguimientoDAO.obtenerTodos();
    }
}
