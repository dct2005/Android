package es.iesagora.ejercicio6.data;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;

@androidx.room.Database(entities = {PeliculaySerie.class, Seguimiento.class},version = 1)
public abstract class Database extends RoomDatabase {
    public abstract PeliculaDAO peliculaDAO();

    public abstract SeguimientoDAO seguimientoDAO();
    // Singleton - Evita múltiples instancias
    private static Database instance;

    // Método para obtener la instancia de la base de datos
    public static Database getInstance(final Context context) {
        if (instance == null) {
            synchronized (Database.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    Database.class,
                                    "Television"
                            )
                            .fallbackToDestructiveMigration()  // Manejo de migración
                            .build();
                }
            }
        }
        return instance;
    }

}
